HAPPY BIRTHDAY DEEPS 💜  —  7-page birthday website
=====================================================
Open  index.html  in Chrome / Edge / Safari (double-click). Works offline. Best on a big screen, volume up.

Pages
 1  Countdown 11:59 → 12:00 (time accelerates) over a huge Earth, then crackers + paper confetti
 2  Login (password 4/11/2003) · moonlit lake · born-moon (right) & today-moon (left) · bgm1
 3  3D "DEEPS" VIP museum · avatar walks the red carpet and visits all 12 photos with blessings · bgm2
 4  Secret door → big photo → 💜D💜 → 12 photos fly into a heart · bgm3
 5  Cake, candles, HAPPY BIRTHDAY DEEPIKA, teddy couple ("Make a Wish Today"), blow candles, cut cake, cheers · music-box
 6  Gift box → divine light → "God bless you" · games: Heart Catch, Quiz, Photo Puzzle
 7  "Happy Birthday Deeps – You smile every day" · lantern sky · heart-shaped QR with Deeps' photo

Edit things  →  js/config.js   (password, blessings, quiz questions, QR text/link, which photos are used)
Swap photos  →  assets/photos/p01.jpg … p12.jpg  AND re-create js/photos-data.js (the 3D museum needs it
                because browsers block local image textures; ask Claude to regenerate it).
Songs        →  assets/audio/bgm1.mp3 (page 2) · bgm2.mp3 (page 3) · bgm3.mp3 (pages 4 & 7)
God image    →  put your own picture at assets/god.png and it replaces the ॐ in the centre of page 6.
QR link      →  on page 7 press "Set link" and paste your hosted website URL (or put it in config.js → siteUrl).
Jump to page →  index.html?p=3   (any number 1-7).
