/* PAGE 5 — cake, candles, HAPPY BIRTHDAY DEEPIKA, teddy couple, cut the cake · gentle music-box */
(function () {
  const drip = (x0, x1, y, n) => { const w = (x1 - x0) / n; let d = `M${x0} ${y - 6}h${x1 - x0}v8`; for (let i = n - 1; i >= 0; i--) { const xr = x0 + (i + 1) * w, xl = x0 + i * w, dp = 10 + ((i * 7) % 3) * 9; d += `L${xr} ${y + 2}q${-w / 2} ${dp * 2} ${-w} 0`; } return `<path d="${d}z" fill="#fff4fb"/>`; };
  const cakeSvg = (id) => `
  <svg viewBox="0 0 400 360" ${id}>
    <defs>
      <linearGradient id="gA${id ? 's' : 'm'}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ff9ccb"/><stop offset="1" stop-color="#e0488f"/></linearGradient>
      <linearGradient id="gB${id ? 's' : 'm'}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d8c2ff"/><stop offset="1" stop-color="#9a6cf0"/></linearGradient>
    </defs>
    <ellipse cx="200" cy="322" rx="190" ry="26" fill="#f3e6ff"/><ellipse cx="200" cy="316" rx="190" ry="24" fill="#fff"/>
    <rect x="50" y="205" width="300" height="112" rx="16" fill="url(#gA${id ? 's' : 'm'})"/>
    ${drip(50,350,205,10)}
    <rect x="96" y="128" width="208" height="86" rx="14" fill="url(#gB${id ? 's' : 'm'})"/>
    ${drip(96,304,128,8)}
    <g fill="#ffd36e"><circle cx="76" cy="262" r="6"/><circle cx="124" cy="270" r="6"/><circle cx="172" cy="262" r="6"/><circle cx="228" cy="262" r="6"/><circle cx="276" cy="270" r="6"/><circle cx="324" cy="262" r="6"/></g>
    <g fill="#ff3d6e"><circle cx="150" cy="122" r="9"/><circle cx="250" cy="122" r="9"/></g>
    <g stroke="#2a8a4a" stroke-width="3" fill="none"><path d="M150 114q4-12 12-14M250 114q4-12 12-14"/></g>
    <g class="candles">
      ${[0, 1, 2, 3, 4].map(i => { const x = 128 + i * 36; const c = ['#ff5ea8', '#ffd36e', '#5ee1ff', '#8b5cff', '#58e08a'][i]; return `<g><rect x="${x - 5}" y="88" width="10" height="42" rx="3" fill="${c}"/><rect x="${x - 5}" y="98" width="10" height="5" fill="#fff" opacity=".6"/><rect x="${x - .8}" y="80" width="1.6" height="9" fill="#333"/><g class="flame" data-c="${i}"><ellipse cx="${x}" cy="70" rx="7" ry="12" fill="#ffb02e"/><ellipse cx="${x}" cy="73" rx="3.6" ry="7.5" fill="#fff6c8"/></g></g>`; }).join('')}
    </g>
  </svg>`;

  const teddySvg = (girl) => `
  <svg viewBox="0 0 200 250">
    <g class="armL"><ellipse cx="42" cy="150" rx="17" ry="30" fill="#b9793f" transform="rotate(25 42 150)"/><circle cx="34" cy="176" r="10" fill="#d99b5e"/></g>
    <g class="armR"><ellipse cx="158" cy="150" rx="17" ry="30" fill="#b9793f" transform="rotate(-25 158 150)"/><circle cx="166" cy="176" r="10" fill="#d99b5e"/></g>
    <ellipse cx="100" cy="170" rx="52" ry="62" fill="#c88a4a"/><ellipse cx="100" cy="178" rx="32" ry="40" fill="#f0c896"/>
    <ellipse cx="70" cy="228" rx="24" ry="17" fill="#b9793f"/><ellipse cx="130" cy="228" rx="24" ry="17" fill="#b9793f"/>
    <ellipse cx="70" cy="230" rx="13" ry="9" fill="#d99b5e"/><ellipse cx="130" cy="230" rx="13" ry="9" fill="#d99b5e"/>
    <circle cx="48" cy="56" r="24" fill="#c88a4a"/><circle cx="152" cy="56" r="24" fill="#c88a4a"/><circle cx="48" cy="56" r="13" fill="#f0c896"/><circle cx="152" cy="56" r="13" fill="#f0c896"/>
    <ellipse cx="100" cy="90" rx="62" ry="56" fill="#c88a4a"/>
    <ellipse cx="100" cy="108" rx="28" ry="21" fill="#f0c896"/><ellipse cx="100" cy="100" rx="9" ry="6.5" fill="#4a2a18"/>
    <g class="eyes"><circle cx="76" cy="84" r="7.5" fill="#2a1408"/><circle cx="124" cy="84" r="7.5" fill="#2a1408"/><circle cx="78.5" cy="81.5" r="2.6" fill="#fff"/><circle cx="126.5" cy="81.5" r="2.6" fill="#fff"/></g>
    <g class="heartEyes" fill="#ff3d6e"><path d="M76 92c-14-9-10-20 0-16 10-4 14 7 0 16z" transform="translate(0,-4) scale(1.1) translate(-7,0)"/><path d="M124 92c-14-9-10-20 0-16 10-4 14 7 0 16z" transform="translate(0,-4) scale(1.1) translate(-7,0)"/></g>
    <ellipse cx="56" cy="104" rx="10" ry="6" fill="#ff8fa8" opacity=".6"/><ellipse cx="144" cy="104" rx="10" ry="6" fill="#ff8fa8" opacity=".6"/>
    <path class="mouthS" d="M88 116q12 11 24 0" stroke="#4a2a18" stroke-width="3.4" fill="none" stroke-linecap="round"/>
    <path class="mouthO" d="M86 114q14 22 28 0z" fill="#7a2a2a"/>
    ${girl ? `<g><path d="M118 40l24-14-4 28z" fill="#ff5ea8"/><path d="M118 40l-24-14 4 28z" fill="#ff5ea8"/><circle cx="118" cy="40" r="7" fill="#ff8fc4"/></g>`
           : `<g><path d="M100 138l-18-10v20z M100 138l18-10v20z" fill="#3a6df0"/><circle cx="100" cy="138" r="6" fill="#2a4fc0"/></g>`}
  </svg>`;

  const html = `
    <div class="p5-lights"><svg viewBox="0 0 1000 90" preserveAspectRatio="none"><path d="M0 8Q250 90 500 20T1000 8" stroke="#6a4a8a" fill="none" stroke-width="2"/>${Array.from({ length: 22 }, (_, i) => { const x = i * 46 + 10, y = 8 + Math.sin(i * .5) * 22 + 20; return `<circle class="p5-bulb" cx="${x}" cy="${y}" r="6" fill="${['#ff5ea8', '#ffd36e', '#5ee1ff', '#b88cff'][i % 4]}" style="animation-delay:${(i % 5) * .4}s"/>`; }).join('')}</svg></div>
    <div class="p5-title" id="p5title"></div>
    <div class="p5-plate" id="p5plate">A slice for you, Deeps 🍰💜</div>
    <div class="p5-scene">
      <div class="teddy" id="tedA" style="opacity:0">${teddySvg(true)}<div class="bubble" id="p5bub">Make a Wish Today 🌠</div></div>
      <div class="p5-cakewrap" id="p5cake">
        <div id="cake" style="position:absolute;inset:0">
          <div class="p5-main" style="position:absolute;inset:0" id="p5main">${cakeSvg('')}</div>
          <div class="p5-slice" id="p5slice" style="position:absolute;inset:0">${cakeSvg('s')}</div>
        </div>
        <svg class="p5-knife" id="p5knife" viewBox="0 0 60 220"><path d="M22 0h16v70H22z" fill="#5a3a24"/><rect x="18" y="66" width="24" height="8" fill="#d8a845"/><path d="M20 74h22l-2 140-20-6z" fill="#e8eef8" stroke="#aab4c8" stroke-width="2"/></svg>
      </div>
      <div class="teddy" id="tedB" style="opacity:0">${teddySvg(false)}<div class="bubble" id="p5bub2">Happy Birthday! 💙</div></div>
    </div>
    <div class="p5-prompt"><p id="p5msg"></p><button class="btn big" id="p5act" style="display:none"></button></div>
    <canvas class="p5-fx" id="p5cf"></canvas><canvas class="p5-fx" id="p5fw"></canvas>`;

  let timers = [], cf, fw, state = 0;
  const T = (f, ms) => timers.push(setTimeout(f, ms));
  const speak = (t) => { try { const u = new SpeechSynthesisUtterance(t); u.pitch = 1.9; u.rate = 1.02; u.volume = .9; if (!Snd.muted) { speechSynthesis.cancel(); speechSynthesis.speak(u); } } catch (e) {} };

  const mod = {
    html,
    init(root) {},
    enter(root) {
      const $ = s => root.querySelector(s);
      timers.forEach(clearTimeout); timers = []; state = 0;
      Snd.stopBgm(900); Snd.startBox();
      cf = new FX.Confetti($('#p5cf')); fw = new FX.Fireworks($('#p5fw')); cf.start(); fw.start();
      // title
      const mk = (t, cls, base) => `<div class="${cls}">${t.split(' ').map((w, wi) => `<span class="w">${[...w].map((ch, i) => `<span class="l" style="color:hsl(${(base + i * 28 + wi * 60) % 360},95%,72%);animation-delay:${.3 + (wi * 6 + i) * .09}s">${ch}</span>`).join('')}</span>`).join('')}</div>`;
      $('#p5title').innerHTML = mk('HAPPY BIRTHDAY', 'l1', 300) + mk('DEEPIKA', 'l2', 20);
      $('#p5plate').style.opacity = 0; $('#p5main').classList.remove('cut'); $('#p5slice').classList.remove('out');
      root.querySelectorAll('.flame').forEach(f => f.classList.remove('off'));
      ['#tedA', '#tedB'].forEach(s => { const t = $(s); t.className = 'teddy'; t.style.opacity = 0; });
      $('#p5bub').classList.remove('show'); $('#p5bub2').classList.remove('show');
      const msg = $('#p5msg'), act = $('#p5act'); act.style.display = 'none'; msg.textContent = '';
      // intro
      T(() => { ['#tedA', '#tedB'].forEach((s, i) => { const t = $(s); t.style.opacity = 1; t.classList.add('pop'); setTimeout(() => t.classList.add(i ? 'love' : 'wave'), 900); }); Snd.pop(); }, 1500);
      T(() => { $('#p5bub').classList.add('show'); speak('Make a wish today'); Snd.sparkle(); $('#tedB').classList.add('wave'); }, 3200);
      T(() => { msg.innerHTML = 'Close your eyes… make a wish 🌠 … then blow the candles 🕯️'; act.textContent = 'Blow the candles 💨'; act.style.display = ''; state = 1; }, 4200);

      const blow = () => {
        if (state !== 1) return; state = 2;
        Snd.blow(); $('#p5bub').classList.remove('show');
        root.querySelectorAll('.flame').forEach((f, i) => { setTimeout(() => { f.classList.add('off'); const r = f.getBoundingClientRect(), s = document.createElement('div'); s.className = 'smoke'; s.style.left = (r.left + r.width / 2 - 9) + 'px'; s.style.top = (r.top - 4) + 'px'; s.style.position = 'fixed'; root.appendChild(s); setTimeout(() => s.remove(), 2300); }, i * 140); });
        ['#tedA', '#tedB'].forEach(s => { const t = $(s); t.classList.remove('wave'); t.classList.add('cheer', 'love'); });
        cf.popper(innerWidth * .15, innerHeight, -Math.PI / 3, .9, 50); cf.popper(innerWidth * .85, innerHeight, -2 * Math.PI / 3, .9, 50);
        $('#p5bub2').textContent = 'Wish made! ✨'; $('#p5bub2').classList.add('show');
        T(() => { $('#p5bub2').classList.remove('show'); msg.textContent = 'Beautiful! Now let\'s cut the cake 🔪🎂'; act.textContent = 'Cut the cake 🔪'; act.style.display = ''; state = 3; ['#tedA', '#tedB'].forEach(s => $(s).classList.remove('cheer')); }, 2400);
        act.style.display = 'none'; msg.textContent = '…';
      };
      const cut = () => {
        if (state !== 3) return; state = 4; act.style.display = 'none'; msg.textContent = '';
        $('#p5knife').classList.add('go'); Snd.cut();
        T(() => { $('#p5main').classList.add('cut'); $('#p5slice').classList.add('out'); Snd.chime([523, 659, 784, 1047], .1); Snd.applause(5);
          ['#tedA', '#tedB'].forEach(s => { const t = $(s); t.classList.remove('love', 'wave'); t.classList.add('clap'); });
          cf.popper(innerWidth * .1, innerHeight, -Math.PI / 3, 1.2, 90); cf.popper(innerWidth * .9, innerHeight, -2 * Math.PI / 3, 1.2, 90); cf.shower(true); fw.show(1.4);
          const b1 = $('#p5bub'); b1.textContent = 'Yaaay! 🎉'; b1.classList.add('show'); const b2 = $('#p5bub2'); b2.textContent = 'Happy Birthday Deeps! 💜'; b2.classList.add('show'); speak('Happy birthday Deeps!');
          for (let i = 0; i < 18; i++) setTimeout(() => { const c = document.createElement('div'); c.className = 'p5-clap'; c.textContent = ['👏', '🎉', '💜', '🥳', '✨'][i % 5]; c.style.left = (5 + Math.random() * 90) + '%'; root.appendChild(c); setTimeout(() => c.remove(), 3500); }, i * 220);
        }, 1000);
        
        T(() => { msg.textContent = 'A slice for you, Deeps 🍰💜 — and your gift is waiting 🎁'; act.textContent = 'Open your gift 🎁'; act.style.display = ''; state = 5; }, 5200);
      };
      act.onclick = () => { if (state === 1) blow(); else if (state === 3) cut(); else if (state === 5) App.go(6); };
      $('#p5cake').onclick = () => { if (state === 1) blow(); else if (state === 3) cut(); };
    },
    leave() { timers.forEach(clearTimeout); timers = []; try { cf.stop(); fw.stop(); speechSynthesis.cancel(); } catch (e) {} }
  };
  App.reg(5, mod);
})();
