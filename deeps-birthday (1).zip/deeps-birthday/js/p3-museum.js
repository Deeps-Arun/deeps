/* PAGE 3 — "DEEPS" VIP museum. A 3D animated avatar walks the red carpet and visits all 12 photos. bgm2 */
(function () {
  const HW = 7, HH = 7.6, GATE_Z = 6, START_Z = 32, END_Z = -78;
  const STZ = [-9, -21, -33, -45, -57, -69];
  const N = 12;

  const html = `
    <canvas class="fill" id="p3cv"></canvas>
    <div class="p3-ui">
      <div class="p3-title"><span class="vip">VIP</span><div><h1>DEEPS</h1><small>museum of smiles</small></div></div>
      <div class="p3-prog" id="p3prog"></div>
      <div class="p3-intro" id="p3intro">Welcome to your museum, Deeps…</div>
      <div class="p3-vip" id="p3vip">VIP ENTRY ✨</div>
      <div class="p3-cap glass" id="p3cap"><div class="n" id="p3n"></div><p id="p3t"></p></div>
      <div class="p3-ctrl"><button id="p3pause" title="Pause">⏸</button><button id="p3skip" title="Next photo">⏭</button></div>
      <button class="btn big next-btn" id="p3next">Open the secret door 🚪</button>
    </div>`;

  /* ───────── helpers ───────── */
  function cvTex(w, h, draw, rep, srgb = true) {
    const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h);
    const t = new THREE.CanvasTexture(c); if (srgb) t.encoding = THREE.sRGBEncoding; t.anisotropy = 8;
    if (rep) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rep[0], rep[1]); }
    return t;
  }
  function rr(x, X, Y, W, H, r) { x.beginPath(); x.moveTo(X + r, Y); x.arcTo(X + W, Y, X + W, Y + H, r); x.arcTo(X + W, Y + H, X, Y + H, r); x.arcTo(X, Y + H, X, Y, r); x.arcTo(X, Y, X + W, Y, r); x.closePath(); }
  function wrap(x, text, maxW) { const words = text.split(' '), lines = []; let l = ''; words.forEach(w => { const t = l ? l + ' ' + w : w; if (x.measureText(t).width > maxW && l) { lines.push(l); l = w; } else l = t; }); lines.push(l); return lines; }
  const M = (o) => new THREE.MeshStandardMaterial(o);

  /* ───────── avatar (stylised 3D girl built from primitives) ───────── */
  function makeAvatar() {
    const g = new THREE.Group(), body = new THREE.Group(); g.add(body);
    const skin = M({ color: 0xd99a6c, roughness: .6 }), hairM = M({ color: 0x120a14, roughness: .35, metalness: .1 });
    const kurta = M({ color: 0x7b3fe4, roughness: .55 }), gold = M({ color: 0xffd36e, roughness: .3, metalness: .6, emissive: 0x3a2600 });
    const pink = M({ color: 0xff5ea8, roughness: .6, side: THREE.DoubleSide }), white = M({ color: 0xf6ecff, roughness: .6 });
    const dark = new THREE.MeshBasicMaterial({ color: 0x1b0d1d });
    const add = (geo, mat, p, parent = body) => { const m = new THREE.Mesh(geo, mat); m.position.set(...p); parent.add(m); return m; };

    // legs
    const legs = [-1, 1].map(s => {
      const hip = new THREE.Group(); hip.position.set(s * .1, .58, 0); body.add(hip);
      add(new THREE.CapsuleGeometry(.065, .4, 4, 10), white, [0, -.28, 0], hip);
      const shoe = add(new THREE.SphereGeometry(.09, 12, 10), gold, [0, -.56, .05], hip); shoe.scale.set(.9, .55, 1.5);
      return hip;
    });
    // kurta
    const skirt = add(new THREE.CylinderGeometry(.19, .32, .66, 28, 1, true), kurta, [0, .86, 0]); skirt.material.side = THREE.DoubleSide;
    add(new THREE.TorusGeometry(.32, .018, 8, 32), gold, [0, .54, 0]).rotation.x = Math.PI / 2;
    add(new THREE.TorusGeometry(.2, .014, 8, 28), gold, [0, 1.17, 0]).rotation.x = Math.PI / 2;
    const chest = add(new THREE.CapsuleGeometry(.17, .16, 6, 16), kurta, [0, 1.23, 0]); chest.scale.set(1.05, 1, .82);
    add(new THREE.CylinderGeometry(.06, .07, .12, 12), skin, [0, 1.42, 0]);
    add(new THREE.TorusGeometry(.085, .012, 8, 20), gold, [0, 1.4, .02]).rotation.x = Math.PI / 2 - .3;
    const sash = add(new THREE.BoxGeometry(.085, .78, .035), pink, [-.03, 1.0, .205]); sash.rotation.z = .42; sash.rotation.x = -.06;
    const sash2 = add(new THREE.BoxGeometry(.09, .55, .03), pink, [.06, .98, -.19]); sash2.rotation.z = -.12;
    // arms
    const arms = [-1, 1].map(s => {
      const sh = new THREE.Group(); sh.position.set(s * .25, 1.32, 0); body.add(sh);
      add(new THREE.CapsuleGeometry(.062, .2, 4, 10), kurta, [0, -.14, 0], sh);
      const el = new THREE.Group(); el.position.set(0, -.3, 0); sh.add(el);
      add(new THREE.CapsuleGeometry(.05, .2, 4, 10), skin, [0, -.13, 0], el);
      add(new THREE.SphereGeometry(.058, 12, 10), skin, [0, -.28, 0], el);
      add(new THREE.TorusGeometry(.055, .011, 6, 14), gold, [0, -.2, 0], el).rotation.x = Math.PI / 2;
      sh.userData.el = el; return sh;
    });
    // head
    const head = new THREE.Group(); head.position.set(0, 1.68, 0); body.add(head);
    const skull = add(new THREE.SphereGeometry(.3, 32, 24), skin, [0, 0, 0], head); skull.scale.set(1, 1.02, .96);
    add(new THREE.SphereGeometry(.318, 32, 20, 0, Math.PI * 2, 0, Math.PI * .56), hairM, [0, .015, -.035], head);
    add(new THREE.SphereGeometry(.31, 24, 18), hairM, [0, -.03, -.09], head).scale.set(1.0, 1.02, .82);
    [-1, 1].forEach(s => { const l = add(new THREE.CapsuleGeometry(.04, .2, 4, 8), hairM, [s * .275, -.06, .06], head); l.rotation.z = s * .12; });
    // parting + fringe wisps
    [-1, 1].forEach(s => { const w = add(new THREE.CapsuleGeometry(.035, .16, 4, 8), hairM, [s * .12, .2, .24], head); w.rotation.z = s * -.9; w.rotation.x = .5; });
    // face
    [-1, 1].forEach(s => {
      const e = add(new THREE.SphereGeometry(.04, 14, 12), dark, [s * .105, .015, .272], head); e.scale.set(1, 1.35, .45);
      add(new THREE.SphereGeometry(.013, 8, 8), new THREE.MeshBasicMaterial({ color: 0xffffff }), [s * .105 + .012, .035, .292], head);
      const br = add(new THREE.BoxGeometry(.075, .012, .01), dark, [s * .105, .09, .275], head); br.rotation.z = s * -.12;
      const ch = add(new THREE.CircleGeometry(.04, 16), new THREE.MeshBasicMaterial({ color: 0xff7a9c, transparent: true, opacity: .45 }), [s * .17, -.06, .235], head); ch.rotation.y = s * .6;
      add(new THREE.SphereGeometry(.028, 10, 10), gold, [s * .3, -.09, .02], head);
      add(new THREE.ConeGeometry(.03, .07, 10), gold, [s * .3, -.15, .02], head).rotation.x = Math.PI;
    });
    const smile = add(new THREE.TorusGeometry(.055, .009, 6, 18, Math.PI), new THREE.MeshBasicMaterial({ color: 0xb33a50 }), [0, -.075, .282], head); smile.rotation.z = Math.PI;
    add(new THREE.SphereGeometry(.022, 10, 10), skin, [0, -.02, .3], head);
    add(new THREE.CircleGeometry(.02, 14), new THREE.MeshBasicMaterial({ color: 0xe0143c }), [0, .13, .282], head);
    // braid
    const braid = []; let parent = new THREE.Group(); parent.position.set(0, -.02, -.3); head.add(parent);
    for (let i = 0; i < 8; i++) {
      const seg = new THREE.Group(); seg.position.set(0, i === 0 ? 0 : -.13, 0); parent.add(seg);
      const b = new THREE.Mesh(new THREE.SphereGeometry(.075 - i * .004, 12, 10), hairM); b.position.y = -.07; b.scale.set(1, 1.2, 1); seg.add(b);
      braid.push(seg); parent = seg;
    }
    const tas = new THREE.Mesh(new THREE.ConeGeometry(.05, .16, 10), pink); tas.position.set(0, -.2, 0); tas.rotation.x = Math.PI; parent.add(tas);
    // flower in hair
    add(new THREE.SphereGeometry(.05, 10, 10), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: .8 }), [.2, .17, -.08], head);
    // shadow blob
    const sh = new THREE.Mesh(new THREE.CircleGeometry(.5, 24), new THREE.MeshBasicMaterial({ map: cvTex(64, 64, (x) => { const gr = x.createRadialGradient(32, 32, 2, 32, 32, 32); gr.addColorStop(0, 'rgba(0,0,0,.6)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = gr; x.fillRect(0, 0, 64, 64); }), transparent: true, depthWrite: false }));
    sh.rotation.x = -Math.PI / 2; sh.position.y = .012; g.add(sh);
    // floating VIP tag
    const tag = new THREE.Sprite(new THREE.SpriteMaterial({ map: cvTex(256, 96, (x, w, h) => { rr(x, 6, 10, w - 12, h - 20, 26); const gr = x.createLinearGradient(0, 0, w, 0); gr.addColorStop(0, '#fff1b8'); gr.addColorStop(1, '#e8a93c'); x.fillStyle = gr; x.fill(); x.fillStyle = '#4a2600'; x.font = '700 46px Quicksand, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('VIP  💜', w / 2, h / 2 + 3); }), transparent: true, depthWrite: false }));
    tag.scale.set(.75, .28, 1); tag.position.set(0, 2.4, 0); g.add(tag);
    g.scale.setScalar(.92);

    let ph = 0, wa = 0, t = 0, pose = 0, jump = 0;
    const api = {
      group: g, tag,
      update(dt, walking, posing, excite) {
        t += dt; wa += ((walking ? 1 : 0) - wa) * Math.min(1, dt * 8); pose += ((posing ? 1 : 0) - pose) * Math.min(1, dt * 5);
        ph += dt * 8.4 * (walking ? 1 : 0);
        const s = Math.sin(ph) * .7 * wa;
        legs[0].rotation.x = s; legs[1].rotation.x = -s;
        arms[0].rotation.x = -s * .8 * (1 - pose); arms[1].rotation.x = s * .8 * (1 - pose) - pose * 1.55;
        arms[1].rotation.z = -pose * .25 + Math.sin(t * 5) * .06 * pose; arms[0].rotation.z = .08 + Math.sin(t * 1.8) * .03 * (1 - wa);
        arms[1].userData.el.rotation.x = -pose * .35;
        body.position.y = Math.abs(Math.sin(ph)) * .05 * wa + Math.sin(t * 2.2) * .008 * (1 - wa) + (excite ? Math.abs(Math.sin(t * 6)) * .1 : 0);
        body.rotation.z = Math.sin(ph) * .035 * wa; body.rotation.x = wa * .06;
        head.rotation.y = Math.sin(t * .9) * .12 * (1 - wa) * (1 - pose); head.rotation.z = Math.sin(t * 1.3) * .04 + pose * .06;
        braid.forEach((b, i) => { b.rotation.x = Math.sin(ph * 1 - i * .55) * .09 * wa + .05; b.rotation.z = Math.sin(t * 1.7 + i * .4) * .05 + Math.sin(ph * .5 - i * .4) * .07 * wa; });
        tag.position.y = 2.4 + Math.sin(t * 2.4) * .05;
      }
    };
    return api;
  }

  /* ───────── the museum ───────── */
  function buildWorld(scene, renderer, onTex) {
    scene.background = new THREE.Color(0x0d0719);
    scene.fog = new THREE.Fog(0x120a24, 26, 88);
    const L = START_Z - END_Z + 10, CZ = (START_Z + END_Z) / 2;

    // floor (polished tiles)
    const floorT = cvTex(512, 512, (x, w, h) => {
      for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) { x.fillStyle = (i + j) % 2 ? '#2a1a45' : '#34205a'; x.fillRect(i * 256, j * 256, 256, 256); }
      for (let k = 0; k < 70; k++) { x.strokeStyle = `rgba(255,255,255,${Math.random() * .06})`; x.lineWidth = Math.random() * 1.6; x.beginPath(); x.moveTo(Math.random() * w, Math.random() * h); x.bezierCurveTo(Math.random() * w, Math.random() * h, Math.random() * w, Math.random() * h, Math.random() * w, Math.random() * h); x.stroke(); }
      x.strokeStyle = '#c99a3c'; x.lineWidth = 3; x.strokeRect(1, 1, w - 2, h - 2); x.beginPath(); x.moveTo(256, 0); x.lineTo(256, h); x.moveTo(0, 256); x.lineTo(w, 256); x.lineWidth = 2; x.stroke();
    }, [HW * 2 / 4, L / 4]);
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(HW * 2, L), M({ map: floorT, roughness: .22, metalness: .25 }));
    floor.rotation.x = -Math.PI / 2; floor.position.set(0, 0, CZ); scene.add(floor);

    // red carpet
    const carT = cvTex(256, 512, (x, w, h) => {
      x.fillStyle = '#5a0c3a'; x.fillRect(0, 0, w, h);
      const g = x.createLinearGradient(0, 0, w, 0); g.addColorStop(0, 'rgba(0,0,0,.35)'); g.addColorStop(.5, 'rgba(120,40,160,.25)'); g.addColorStop(1, 'rgba(0,0,0,.35)'); x.fillStyle = g; x.fillRect(0, 0, w, h);
      x.fillStyle = '#e3b04b'; x.fillRect(10, 0, 8, h); x.fillRect(w - 18, 0, 8, h); x.fillRect(24, 0, 3, h); x.fillRect(w - 27, 0, 3, h);
      x.strokeStyle = 'rgba(255,214,120,.55)'; x.lineWidth = 2;
      for (let j = 0; j < 4; j++) { const cy = 64 + j * 128; x.beginPath(); x.moveTo(w / 2, cy - 48); x.lineTo(w / 2 + 48, cy); x.lineTo(w / 2, cy + 48); x.lineTo(w / 2 - 48, cy); x.closePath(); x.stroke(); x.beginPath(); x.arc(w / 2, cy, 8, 0, 7); x.fillStyle = 'rgba(255,214,120,.6)'; x.fill(); }
    }, [1, L / 8]);
    const carpet = new THREE.Mesh(new THREE.PlaneGeometry(3.6, L - 6), M({ map: carT, roughness: .95 }));
    carpet.rotation.x = -Math.PI / 2; carpet.position.set(0, .012, CZ); scene.add(carpet);

    // walls
    const wallT = cvTex(512, 512, (x, w, h) => {
      const g = x.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#2c1757'); g.addColorStop(1, '#43246f'); x.fillStyle = g; x.fillRect(0, 0, w, h);
      x.fillStyle = '#1c0e36'; x.fillRect(0, h * .72, w, h * .28);
      x.strokeStyle = '#d8a845'; x.lineWidth = 5; x.beginPath(); x.moveTo(0, h * .72); x.lineTo(w, h * .72); x.moveTo(0, 6); x.lineTo(w, 6); x.stroke();
      x.lineWidth = 2; x.strokeStyle = 'rgba(216,168,69,.7)'; x.strokeRect(24, h * .76, w - 48, h * .2);
      x.strokeStyle = 'rgba(255,255,255,.04)'; for (let i = 0; i < 6; i++) { x.beginPath(); x.moveTo(i * 85, 8); x.lineTo(i * 85, h * .72); x.stroke(); }
    }, [L / 7, 1]);
    [-1, 1].forEach(s => { const w = new THREE.Mesh(new THREE.PlaneGeometry(L, HH), M({ map: wallT, roughness: .85 })); w.rotation.y = -s * Math.PI / 2; w.position.set(s * HW, HH / 2, CZ); w.material.map.repeat.set(L / 7, 1); scene.add(w); });

    // ceiling with light strips
    const ceil = new THREE.Mesh(new THREE.PlaneGeometry(HW * 2, L), M({ color: 0x150b2b, roughness: .9 })); ceil.rotation.x = Math.PI / 2; ceil.position.set(0, HH, CZ); scene.add(ceil);
    const strip = new THREE.MeshBasicMaterial({ color: 0xfff1d0 });
    for (let z = START_Z - 2; z > END_Z; z -= 5.5) { const b = new THREE.Mesh(new THREE.BoxGeometry(3.4, .08, .5), strip); b.position.set(0, HH - .05, z); scene.add(b); }
    [-1, 1].forEach(s => { const c = new THREE.Mesh(new THREE.BoxGeometry(.25, .22, L), M({ color: 0xd8a845, metalness: .6, roughness: .3, emissive: 0x2a1a00 })); c.position.set(s * (HW - .12), HH - .11, CZ); scene.add(c); });

    // end wall + secret door
    const endW = new THREE.Mesh(new THREE.PlaneGeometry(HW * 2, HH), M({ map: wallT.clone(), roughness: .9 })); endW.material.map.repeat.set(2, 1); endW.position.set(0, HH / 2, END_Z - 3); scene.add(endW);
    const doorGlow = new THREE.Mesh(new THREE.PlaneGeometry(4.6, 5.8), new THREE.MeshBasicMaterial({ map: cvTex(128, 256, (x, w, h) => { const g = x.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#ffd9ff'); g.addColorStop(1, '#8a5cff'); x.fillStyle = g; rr(x, 0, 0, w, h, 60); x.fill(); x.fillStyle = 'rgba(255,255,255,.55)'; x.fillRect(w / 2 - 1.5, 0, 3, h); x.fillStyle = '#fff'; x.font = '44px serif'; x.textAlign = 'center'; x.fillText('💜', w / 2, h * .55); }), transparent: true }));
    doorGlow.position.set(0, 2.9, END_Z - 2.92); scene.add(doorGlow);
    const dframe = new THREE.Mesh(new THREE.BoxGeometry(5.2, 6.3, .2), M({ color: 0xd8a845, metalness: .5, roughness: .35, emissive: 0x2a1a00 })); dframe.position.set(0, 3.1, END_Z - 3.05); scene.add(dframe);
    const dtext = new THREE.Mesh(new THREE.PlaneGeometry(6, 1), new THREE.MeshBasicMaterial({ map: cvTex(512, 90, (x, w, h) => { x.fillStyle = '#ffe9a8'; x.font = '700 40px Playfair, serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.shadowColor = '#ffb534'; x.shadowBlur = 16; x.fillText('✦  THE SECRET DOOR  ✦', w / 2, h / 2); }), transparent: true }));
    dtext.position.set(0, 6.7, END_Z - 2.9); scene.add(dtext);
    const dl = new THREE.PointLight(0xc9a8ff, 1.4, 16); dl.position.set(0, 3, END_Z + 1); scene.add(dl);

    // gate wall with DEEPS sign
    const gateM = M({ color: 0x2a1650, roughness: .8 });
    [-1, 1].forEach(s => { const b = new THREE.Mesh(new THREE.BoxGeometry(HW - 3, HH, .6), gateM); b.position.set(s * (3 + (HW - 3) / 2), HH / 2, GATE_Z); scene.add(b); });
    const lint = new THREE.Mesh(new THREE.BoxGeometry(HW * 2, 2.5, .6), gateM); lint.position.set(0, HH - 1.25, GATE_Z); scene.add(lint);
    [-1, 1].forEach(s => { const p = new THREE.Mesh(new THREE.BoxGeometry(.35, HH - 2.4, .8), M({ color: 0xd8a845, metalness: .6, roughness: .3, emissive: 0x2a1a00 })); p.position.set(s * 3.05, (HH - 2.4) / 2, GATE_Z + .05); scene.add(p); });
    const signMat = new THREE.MeshBasicMaterial({ transparent: true });
    const drawSign = () => { signMat.map = cvTex(1400, 340, (x, w, h) => {
      x.fillStyle = '#1a0b36'; rr(x, 8, 8, w - 16, h - 16, 40); x.fill(); x.lineWidth = 8; x.strokeStyle = '#e3b04b'; rr(x, 8, 8, w - 16, h - 16, 40); x.stroke();
      x.textAlign = 'center'; x.textBaseline = 'middle'; x.shadowColor = '#ffb534'; x.shadowBlur = 36;
      const g = x.createLinearGradient(0, 40, 0, 270); g.addColorStop(0, '#fff7d6'); g.addColorStop(1, '#e7a53a'); x.fillStyle = g;
      x.font = '700 210px Playfair, Georgia, serif'; x.fillText('D E E P S', w / 2, h * .46);
      x.shadowBlur = 8; x.font = '600 34px Quicksand, sans-serif'; x.fillStyle = '#ffe3a0'; x.fillText('✦  VIP  MUSEUM  OF  SMILES  ✦', w / 2, h * .85);
    }); signMat.needsUpdate = true; onTex && onTex(); };
    drawSign(); if (document.fonts && document.fonts.load) Promise.all([document.fonts.load('700 100px Playfair'), document.fonts.load('600 30px Quicksand')]).then(drawSign).catch(() => {});
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(11.6, 2.35), signMat); sign.position.set(0, HH - 1.25, GATE_Z + .32); scene.add(sign);
    const sg = new THREE.PointLight(0xffd9a0, 1.2, 22); sg.position.set(0, 5, GATE_Z + 6); scene.add(sg);

    // VIP stanchions + ropes (foyer)
    const goldM = M({ color: 0xe3b04b, metalness: .7, roughness: .25, emissive: 0x2a1a00 }), ropeM = M({ color: 0xa3122f, roughness: .7 });
    const post = (x, z) => { const p = new THREE.Group(); p.position.set(x, 0, z); const c = new THREE.Mesh(new THREE.CylinderGeometry(.04, .05, 1, 10), goldM); c.position.y = .5; const b = new THREE.Mesh(new THREE.CylinderGeometry(.2, .24, .06, 16), goldM); b.position.y = .03; const k = new THREE.Mesh(new THREE.SphereGeometry(.09, 12, 10), goldM); k.position.y = 1.02; p.add(c, b, k); scene.add(p); return p; };
    for (let z = GATE_Z + 4; z <= START_Z - 2; z += 4) {
      [-2.3, 2.3].forEach(x => post(x, z));
      if (z + 4 <= START_Z - 2) [-2.3, 2.3].forEach(x => { const r = new THREE.Mesh(new THREE.CylinderGeometry(.025, .025, 3.84, 8), ropeM); r.rotation.x = Math.PI / 2; r.position.set(x, .9, z + 2); scene.add(r); });
    }
    // gate rope (drops when the VIP arrives)
    const ropeG = new THREE.Group(); ropeG.position.set(-2.6, .92, GATE_Z + 1.4); scene.add(ropeG);
    post(-2.6, GATE_Z + 1.4); post(2.6, GATE_Z + 1.4);
    const rp = new THREE.Mesh(new THREE.CylinderGeometry(.035, .035, 5.2, 10), ropeM); rp.rotation.z = Math.PI / 2; rp.position.x = 2.6; ropeG.add(rp);
    const tassel = new THREE.Mesh(new THREE.SphereGeometry(.09, 10, 8), goldM); tassel.position.x = 5.2; ropeG.add(tassel);
    // red "VIP" floor spotlight circle at the gate
    const ring = new THREE.Mesh(new THREE.RingGeometry(1.1, 1.3, 40), new THREE.MeshBasicMaterial({ color: 0xffd36e, transparent: true, opacity: .8, side: THREE.DoubleSide })); ring.rotation.x = -Math.PI / 2; ring.position.set(0, .03, GATE_Z + 3.4); scene.add(ring);

    // lights
    scene.add(new THREE.HemisphereLight(0xe8dcff, 0x442266, .75));
    const plights = [];
    [START_Z - 8, 16, ...STZ, END_Z + 6].forEach((z, i) => { const l = new THREE.PointLight(0xffe2b5, i < 2 ? .9 : 1.05, 22, 1.6); l.position.set(0, HH - 1.2, z); scene.add(l); plights.push(l); });

    // photos
    const loader = new THREE.TextureLoader(), frames = [];
    const glowT = cvTex(128, 128, (x) => { const g = x.createRadialGradient(64, 64, 4, 64, 64, 64); g.addColorStop(0, 'rgba(255,226,160,.55)'); g.addColorStop(1, 'rgba(255,226,160,0)'); x.fillStyle = g; x.fillRect(0, 0, 128, 128); });
    for (let i = 0; i < N; i++) {
      const k = i >> 1, side = (i % 2 === 0) ? -1 : 1, zk = STZ[k];
      const grp = new THREE.Group(); grp.position.set(side * (HW - .02), 3.1, zk); grp.rotation.y = -side * Math.PI / 2; scene.add(grp);
      const gl = new THREE.Mesh(new THREE.PlaneGeometry(9.5, 7), new THREE.MeshBasicMaterial({ map: glowT, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false })); gl.position.z = .01; grp.add(gl);
      const holder = new THREE.Group(); grp.add(holder);
      const pm = new THREE.MeshBasicMaterial({ color: 0x333333 });
      const photo = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), pm); photo.position.z = .13; holder.add(photo);
      const mat = new THREE.Mesh(new THREE.BoxGeometry(1, 1, .1), M({ color: 0xfaf3e8, roughness: .9 })); mat.position.z = .06; holder.add(mat);
      const fr = new THREE.Mesh(new THREE.BoxGeometry(1, 1, .16), M({ color: 0xd8a845, metalness: .55, roughness: .3, emissive: 0x2a1a00 })); fr.position.z = .04; holder.add(fr);
      const sz = (w, h) => { const pw = w, ph = h; photo.scale.set(pw, ph, 1); mat.scale.set(pw + .28, ph + .28, 1); fr.scale.set(pw + .6, ph + .6, 1); };
      sz(4, 2.25);
      loader.load(App.photo(i + 1), t => {
        t.encoding = THREE.sRGBEncoding; t.anisotropy = 8; pm.map = t; pm.color.set(0xffffff); pm.needsUpdate = true;
        const asp = t.image.width / t.image.height; let w = 5.0, h = w / asp; if (h > 3.2) { h = 3.2; w = h * asp; } if (asp < 1) { h = 3.3; w = h * asp; } sz(w, h);
      });
      // blessing placard
      const txt = (CFG.blessings[i] || '');
      const plT = cvTex(1024, 190, (x, w, h) => {
        rr(x, 4, 4, w - 8, h - 8, 28); x.fillStyle = 'rgba(24,10,48,.92)'; x.fill(); x.strokeStyle = '#e3b04b'; x.lineWidth = 5; x.stroke();
        x.fillStyle = '#ffd36e'; x.font = '700 24px Quicksand, sans-serif'; x.textAlign = 'center'; x.fillText('✦  No. ' + String(i + 1).padStart(2, '0') + '  ✦', w / 2, 40);
        x.fillStyle = '#fff'; x.font = 'italic 600 38px Playfair, Georgia, serif'; const ls = wrap(x, txt, w - 100); ls.slice(0, 2).forEach((l, j) => x.fillText(l, w / 2, 94 + j * 46 - (ls.length > 1 ? 4 : -14)));
      });
      const pl = new THREE.Mesh(new THREE.PlaneGeometry(5.0, .93), new THREE.MeshBasicMaterial({ map: plT, transparent: true })); pl.position.set(0, -2.42, .08); grp.add(pl);
      frames.push({ grp, side, zk, plT });
    }
    // re-draw placards once the fonts arrive
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => frames.forEach(f => { f.plT.needsUpdate = true; }));

    // gold dust
    const dn = 420, dp = new Float32Array(dn * 3);
    for (let i = 0; i < dn; i++) { dp[i * 3] = (Math.random() - .5) * HW * 2; dp[i * 3 + 1] = Math.random() * HH; dp[i * 3 + 2] = END_Z + Math.random() * (START_Z - END_Z); }
    const dg = new THREE.BufferGeometry(); dg.setAttribute('position', new THREE.BufferAttribute(dp, 3));
    const dust = new THREE.Points(dg, new THREE.PointsMaterial({ size: .09, map: glowT, color: 0xffe2a0, transparent: true, opacity: .8, blending: THREE.AdditiveBlending, depthWrite: false })); scene.add(dust);

    return { frames, ropeG, dust, ring, plights, doorGlow };
  }

  /* ───────── page logic ───────── */
  let S = null;
  const mod = {
    html,
    init(root) {},
    enter(root) {
      const $ = s => root.querySelector(s);
      Snd.bgm('bgm2', 0.8);
      // progress dots
      $('#p3prog').innerHTML = Array.from({ length: N }, () => '<i></i>').join('');
      $('#p3next').classList.remove('show'); $('#p3cap').classList.remove('show');

      const cv = $('#p3cv');
      const renderer = new THREE.WebGLRenderer({ canvas: cv, antialias: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6)); renderer.outputEncoding = THREE.sRGBEncoding;
      const scene = new THREE.Scene();
      const cam = new THREE.PerspectiveCamera(52, 1, .1, 220);
      const world = buildWorld(scene, renderer);
      const av = makeAvatar(); scene.add(av.group);
      av.group.position.set(0, 0, START_Z); av.group.rotation.y = Math.PI;
      // soft light that follows her
      const pl = new THREE.PointLight(0xffd0f0, .7, 7); scene.add(pl);

      const size = () => { const w = root.clientWidth || innerWidth, h = root.clientHeight || innerHeight; renderer.setSize(w, h, false); cam.aspect = w / h; cam.fov = w / h < .9 ? 66 : 48; cam.updateProjectionMatrix(); };
      size(); this._rs = size; addEventListener('resize', size);

      S = { run: true, paused: false, renderer, scene, cam, av, world, steps: [], si: 0, step: null, mode: 'follow', view: null, hold: 0, heading: Math.PI, camPos: new THREE.Vector3(0, 3.4, START_Z + 7), camLook: new THREE.Vector3(0, 1.6, START_Z - 6), cur: -1, t: 0, ropeT: -1, end: false };
      cam.position.copy(S.camPos);

      // build the tour
      const st = [];
      const spot = i => { const k = i >> 1, side = (i % 2 === 0) ? -1 : 1; return { x: side * 4.5, z: STZ[k] + 3.3, side, zk: STZ[k] }; };
      st.push({ t: 'call', fn: () => { $('#p3intro').classList.add('go'); } });
      st.push({ t: 'walk', pts: [[0, GATE_Z + 4.6]], speed: 3.5 });
      st.push({ t: 'call', fn: () => { S.ropeT = 0; const v = $('#p3vip'); v.classList.remove('go'); void v.offsetWidth; v.classList.add('go'); Snd.chime([392, 523, 659, 784, 1047], .1); Snd.sparkle(); } });
      st.push({ t: 'wait', ms: 1700 });
      let pos = { x: 0, z: GATE_Z + 4.6 };
      for (let i = 0; i < N; i++) {
        const sp = spot(i), pts = [];
        if (i === 0) { pts.push([0, sp.z]); }
        else { const pv = spot(i - 1); if (pv.zk !== sp.zk) pts.push([pv.side * 1.2, pv.z], [0, pv.z - 1.5], [0, sp.z + 1.5]); else pts.push([0, pv.z]); pts.push([0, sp.z]); }
        pts.push([sp.x, sp.z]);
        st.push({ t: 'walk', pts, speed: 3.6, mode: 'follow' });
        st.push({ t: 'face', hx: sp.side, hz: -.28 });
        st.push({ t: 'show', i, sp });
        st.push({ t: 'hold', ms: 5200 });
        st.push({ t: 'hide' });
      }
      const lastSpot = spot(N - 1);
      st.push({ t: 'walk', pts: [[0, lastSpot.z], [0, END_Z + 7]], speed: 3.8, mode: 'follow' });
      st.push({ t: 'face', hx: 0, hz: -1 });
      st.push({ t: 'call', fn: () => { S.mode = 'end'; Snd.unlock(); $('#p3next').classList.add('show'); $('#p3cap').classList.remove('show'); } });
      S.steps = st;

      const adv = () => { S.step = S.steps[S.si++]; S.stepT = 0; S.pi = 0; if (!S.step) return; const s = S.step;
        if (s.t === 'call') { s.fn(); S.step = null; adv(); }
        else if (s.t === 'show') { S.cur = s.i; S.mode = 'view'; S.view = s.sp; document.querySelectorAll('#p3prog i').forEach((d, k) => d.classList.toggle('on', k <= s.i)); $('#p3n').textContent = 'Photo ' + (s.i + 1) + ' of ' + N; $('#p3t').textContent = CFG.blessings[s.i] || ''; $('#p3cap').classList.add('show'); S.posing = true; Snd.chime([659, 784, 988], .08); for (let h = 0; h < 5; h++) setTimeout(() => heart(root), h * 380); S.step = null; adv(); }
        else if (s.t === 'hide') { $('#p3cap').classList.remove('show'); S.posing = false; S.mode = 'follow'; S.step = null; adv(); }
        else if (s.t === 'walk') { S.mode = 'follow'; }
      };
      this.adv = adv;
      adv();
      // debug helper (used for automated screenshots): jump straight to a photo
      window.__p3view = i => { const sp = spot(i); S.step = { t: 'hold', ms: 1e9 }; S.mode = 'view'; S.view = sp; S.posing = true; S.stepT = 2000; S.heading = Math.atan2(sp.side, -.28); av.group.position.set(sp.x, 0, sp.z);
        $('#p3t').textContent = CFG.blessings[i]; $('#p3n').textContent = 'Photo ' + (i + 1) + ' of ' + N; $('#p3cap').classList.add('show'); S.camPos.set(-sp.side * 1.5, 2.3, sp.zk + 1); S.camLook.set(sp.side * HW, 2.15, sp.zk + 1.3); };
      window.__p3end = () => { S.si = S.steps.length - 3; const lp = spot(N - 1); av.group.position.set(lp.x, 0, lp.z); adv(); };

      $('#p3pause').onclick = e => { S.paused = !S.paused; e.target.textContent = S.paused ? '▶' : '⏸'; };
      $('#p3skip').onclick = () => { if (S.step && S.step.t === 'hold') S.stepT = 1e9; };
      $('#p3next').onclick = () => App.go(4);

      let last = performance.now();
      const loop = now => {
        if (!S || !S.run) return; requestAnimationFrame(loop);
        let dt = Math.min(.05, (now - last) / 1000); last = now; dt *= (window.__TS || 1); if (!S.paused) update(dt, root); render();
      };
      requestAnimationFrame(loop);
      const update = (dt) => {
        S.t += dt;
        const g = av.group; let walking = false;
        const s = S.step;
        if (s) {
          S.stepT += dt * 1000;
          if (s.t === 'walk') {
            walking = true;
            const tgt = s.pts[S.pi]; const dx = tgt[0] - g.position.x, dz = tgt[1] - g.position.z, d = Math.hypot(dx, dz);
            if (d < .08) { S.pi++; if (S.pi >= s.pts.length) { walking = false; S.step = null; adv(); } }
            else { const sp = Math.min(d, s.speed * dt); g.position.x += dx / d * sp; g.position.z += dz / d * sp; S.heading = angLerp(S.heading, Math.atan2(dx, dz), 1 - Math.exp(-9 * dt)); }
          } else if (s.t === 'face') {
            S.heading = angLerp(S.heading, Math.atan2(s.hx, s.hz), 1 - Math.exp(-7 * dt));
            if (S.stepT > 650) { S.step = null; adv(); }
          } else if (s.t === 'hold') { if (S.stepT >= s.ms) { S.step = null; adv(); } }
          else if (s.t === 'wait') { if (S.stepT >= s.ms) { S.step = null; adv(); } }
        }
        g.rotation.y = S.heading;
        av.update(dt, walking, !!S.posing, !!S.posing && S.stepT > 800 && S.stepT < 1800);
        pl.position.set(g.position.x, 3, g.position.z + 1);
        // rope drop
        if (S.ropeT >= 0) { S.ropeT += dt; const k = Math.min(1, S.ropeT / 1.1); world.ropeG.rotation.z = -k * k * 1.45; world.ropeG.position.y = .92 - k * .05; }
        world.ring.material.opacity = .45 + Math.sin(S.t * 3) * .35; world.ring.scale.setScalar(1 + Math.sin(S.t * 3) * .05);
        world.doorGlow.material.opacity = S.mode === 'end' ? .85 + Math.sin(S.t * 4) * .15 : .8;
        // dust drift
        const dpA = world.dust.geometry.attributes.position; for (let i = 0; i < dpA.count; i++) { let y = dpA.getY(i) + dt * .08; if (y > HH) y = 0; dpA.setY(i, y); } dpA.needsUpdate = true;

        // camera
        let tp, tl;
        const f = new THREE.Vector3(Math.sin(S.heading), 0, Math.cos(S.heading));
        if (S.mode === 'view' && S.view) {
          const v = S.view; tp = new THREE.Vector3(-v.side * 1.5, 2.3, v.zk + 1.0); tl = new THREE.Vector3(v.side * HW, 2.15, v.zk + 1.3);
          if (cam.aspect < .9) { tp.x = -v.side * 5.6; tl.z = v.zk + 1.2; tp.y = 2.9; }
        } else if (S.mode === 'end') {
          tp = new THREE.Vector3(0, 2.6, END_Z + 14); tl = new THREE.Vector3(0, 2.7, END_Z);
        } else {
          tp = g.position.clone().addScaledVector(f, -5.2).add(new THREE.Vector3(0, 2.7, 0)); tl = g.position.clone().addScaledVector(f, 3.5); tl.y = 1.5;
          tp.x = THREE.MathUtils.clamp(tp.x, -HW + 1, HW - 1);
          tp.z = Math.min(tp.z, START_Z + 9);
        }
        const kp = 1 - Math.exp(-(S.mode === 'view' ? 2.4 : 3.2) * dt);
        S.camPos.lerp(tp, kp); S.camLook.lerp(tl, 1 - Math.exp(-4 * dt));
        cam.position.copy(S.camPos); cam.lookAt(S.camLook);
      };
      const render = () => renderer.render(scene, cam);
      this._update = update; this._render = render;
    },
    leave() {
      if (!S) return; S.run = false; removeEventListener('resize', this._rs);
      document.querySelectorAll('.p3-heart').forEach(h => h.remove());
      try { S.renderer.dispose(); } catch (e) {} S = null;
    }
  };
  function angLerp(a, b, k) { let d = ((b - a + Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI; return a + d * k; }
  function heart(root) {
    const h = document.createElement('div'); h.className = 'p3-heart'; h.textContent = ['💜', '💖', '✨', '💫'][Math.random() * 4 | 0];
    h.style.left = (30 + Math.random() * 40) + '%'; root.querySelector('.p3-ui').appendChild(h); setTimeout(() => h.remove(), 3300);
  }
  App.reg(3, mod);
})();
