/* PAGE 1 — 11:59 → 12:00 accelerating countdown over a huge procedural Earth, then crackers + paper confetti */
(function () {
  const html = `
    <canvas class="fill" id="p1earth"></canvas>
    <canvas class="fill" id="p1fw"></canvas>
    <canvas class="fill" id="p1cf"></canvas>
    <div class="p1-ui">
      <div class="p1-top">
        <span class="p1-tag">✦ birthday countdown ✦</span>
        <div class="p1-clock"><span id="p1h">11</span><i>:</i><span id="p1m">59</span><i>:</i><span id="p1s">00</span><small id="p1ap">PM</small></div>
        <div class="p1-sub">3 November · Deeps' day begins at 12:00 AM</div>
        <div class="p1-speed" id="p1speed"><span>⏩ time speed</span><div class="bar"><b id="p1bar"></b></div><em id="p1x">×1.0</em></div>
      </div>
      <div class="p1-ring" id="p1ring"></div><div class="p1-ring r2" id="p1ring2"></div>
      <div class="p1-big" id="p1big"></div>
      <div class="p1-hb hidden" id="p1hb"><h1 class="script">Happy Birthday</h1><h2 class="script">Deeps!</h2></div>
      <div class="p1-flash" id="p1flash"></div>
      <button class="btn big next-btn" id="p1next">Open the surprise 💜</button>
    </div>`;

  const VERT = `varying vec3 vObj;varying vec3 vN;varying vec3 vV;
  void main(){vObj=position;vN=normalize(normalMatrix*normal);vec4 mv=modelViewMatrix*vec4(position,1.);vV=-mv.xyz;gl_Position=projectionMatrix*mv;}`;
  const NOISE = `
  float hash(vec3 p){p=fract(p*0.3183099+.1);p*=17.0;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}
  float noise(vec3 x){vec3 i=floor(x);vec3 f=fract(x);f=f*f*(3.0-2.0*f);
   return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),
              mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);}
  float fbm(vec3 p){float a=.5,s=0.;for(int i=0;i<6;i++){s+=a*noise(p);p*=2.03;a*=.5;}return s;}
  float fbm4(vec3 p){float a=.5,s=0.;for(int i=0;i<4;i++){s+=a*noise(p);p*=2.03;a*=.5;}return s;}`;
  const FRAG = `precision highp float;varying vec3 vObj;varying vec3 vN;varying vec3 vV;
  uniform vec3 uSun;uniform float uTime;uniform float uGlow;` + NOISE + `
  void main(){
    vec3 p=normalize(vObj);
    float h=fbm(p*2.4+3.1);
    float land=smoothstep(.52,.565,h);
    float lat=abs(p.y);
    vec3 deep=vec3(.01,.045,.2),shallow=vec3(.03,.3,.58);
    vec3 ocean=mix(deep,shallow,smoothstep(.34,.53,h));
    float m=fbm4(p*5.+10.);
    vec3 grass=vec3(.07,.33,.1),dry=vec3(.62,.5,.25),rock=vec3(.38,.32,.26);
    vec3 lc=mix(grass,dry,smoothstep(.35,.72,m));
    lc=mix(lc,dry,smoothstep(.22,.0,abs(lat-.3))*.65);
    lc=mix(lc,rock,smoothstep(.62,.76,h));
    float ice=smoothstep(.84,.95,lat+(h-.5)*.25);
    vec3 col=mix(ocean,lc,land);col=mix(col,vec3(.93,.96,1.),ice);
    float cl=fbm4(p*3.6+vec3(uTime*.015,uTime*.01,0.));
    cl=smoothstep(.56,.85,cl);
    col=mix(col,vec3(1.),cl*.62);
    vec3 N=normalize(vN);vec3 V=normalize(vV);
    float d=dot(N,uSun);
    float day=smoothstep(-.08,.3,d);
    vec3 lit=col*(0.06+0.95*max(d,0.));
    vec3 R=reflect(-uSun,N);
    float spec=pow(max(dot(R,V),0.),50.)*(1.-land)*(1.-ice)*(1.-cl);
    lit+=vec3(.85,.92,1.)*spec*.7*day;
    float cities=smoothstep(.6,.78,fbm4(p*16.))*land*(1.-ice);
    float night=1.-smoothstep(-.12,.18,d);
    lit+=vec3(1.,.72,.3)*cities*night*(1.2+uGlow*3.);
    lit+=vec3(1.,.4,.15)*pow(1.-min(abs(d)*2.,1.),5.)*day*.18;
    float rim=pow(1.-max(dot(N,V),0.),3.);
    lit+=vec3(.25,.5,1.)*rim*(.35+.65*max(d+.35,0.))+vec3(1.,.8,.5)*rim*uGlow*.5;
    lit=lit/(1.+lit*.22)*1.15;
    gl_FragColor=vec4(lit,1.);
  }`;
  const ATM_F = `varying vec3 vN;varying vec3 vV;uniform float uGlow;
  void main(){float f=dot(normalize(vN),normalize(vV));float a=pow(clamp(1.0+f*1.55,0.,1.),3.2);
    vec3 c=mix(vec3(.25,.55,1.),vec3(1.,.7,.9),uGlow);gl_FragColor=vec4(c,a*(.95+uGlow*.5));}`;

  let st = null;

  function build(root) {
    const cv = root.querySelector('#p1earth');
    const renderer = new THREE.WebGLRenderer({ canvas: cv, antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    const scene = new THREE.Scene();
    const cam = new THREE.PerspectiveCamera(40, 1, 0.1, 400);
    cam.position.set(0, 0, 6);
    const uni = { uSun: { value: new THREE.Vector3(-0.55, 0.55, 0.65).normalize() }, uTime: { value: 0 }, uGlow: { value: 0 } };
    const R = 5;
    const earth = new THREE.Mesh(new THREE.SphereGeometry(R, 96, 64), new THREE.ShaderMaterial({ uniforms: uni, vertexShader: VERT, fragmentShader: FRAG }));
    earth.position.set(0, -5.3, 0); earth.rotation.x = -1.0; earth.rotation.z = 0.2;
    scene.add(earth);
    const atm = new THREE.Mesh(new THREE.SphereGeometry(R * 1.07, 64, 48), new THREE.ShaderMaterial({ uniforms: uni, vertexShader: VERT, fragmentShader: ATM_F, side: THREE.BackSide, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false }));
    atm.position.copy(earth.position); scene.add(atm);
    // stars
    const N = 1800, pos = new Float32Array(N * 3), col = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      const r = 40 + Math.random() * 60, th = Math.random() * Math.PI * 2, ph = Math.acos(2 * Math.random() - 1);
      pos[i * 3] = r * Math.sin(ph) * Math.cos(th); pos[i * 3 + 1] = r * Math.cos(ph) * .8 + 6; pos[i * 3 + 2] = -Math.abs(r * Math.sin(ph) * Math.sin(th)) - 10;
      const c = new THREE.Color().setHSL(Math.random() < .5 ? .62 : (Math.random() < .5 ? .08 : .85), .5, .55 + Math.random() * .4);
      col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
    }
    const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.BufferAttribute(pos, 3)); sg.setAttribute('color', new THREE.BufferAttribute(col, 3));
    const stars = new THREE.Points(sg, new THREE.PointsMaterial({ size: 0.55, vertexColors: true, transparent: true, opacity: .95, sizeAttenuation: true, depthWrite: false }));
    scene.add(stars);
    function size() { const w = root.clientWidth || innerWidth, h = root.clientHeight || innerHeight; renderer.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); cam.position.z = w / h < 0.8 ? 7.5 : 6; }
    size();
    return { renderer, scene, cam, earth, atm, stars, uni, size };
  }

  // choose k so that v(T) = 50 virtual seconds in T real seconds, rate starts at 1x and grows exponentially
  function solveK(T, target) { let lo = 0.0001, hi = 1; for (let i = 0; i < 60; i++) { const k = (lo + hi) / 2; ((Math.exp(k * T) - 1) / k > target) ? hi = k : lo = k; } return (lo + hi) / 2; }

  const mod = {
    html,
    init(root) { root.style.opacity = ''; },
    enter(root) {
      this.root = root;
      const $ = s => root.querySelector(s);
      const T3D = build(root);
      const fw = new FX.Fireworks($('#p1fw')), cf = new FX.Confetti($('#p1cf'));
      st = { T3D, fw, cf, run: true, t0: 0, phase: 'wait', lastSec: -1, lastBig: -1 };
      const T = 14, K = solveK(T, 50), clockEls = { h: $('#p1h'), m: $('#p1m'), s: $('#p1s'), ap: $('#p1ap') };
      // reset UI
      root.querySelector('.p1-top').classList.remove('small'); $('#p1hb').classList.add('hidden'); $('#p1hb').classList.remove('in'); $('#p1next').classList.remove('show');
      clockEls.h.textContent = '11'; clockEls.m.textContent = '59'; clockEls.s.textContent = '00'; clockEls.ap.textContent = 'PM';
      $('#p1speed').style.opacity = 1;
      cf.start(); fw.start();
      let startAt = performance.now() + 1500, last = performance.now(), spin = 0.04, virt = 0, rate = 1;
      const tick = (big) => Snd.tick(big);

      const pop = el => { el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop'); };

      const midnight = async () => {
        st.phase = 'boom';
        $('#p1speed').style.opacity = 0;
        clockEls.h.textContent = '12'; clockEls.m.textContent = '00'; clockEls.s.textContent = '00'; clockEls.ap.textContent = 'AM';
        root.querySelector('.p1-sub').textContent = '4 November · Happy Birthday Deeps!';
        root.querySelector('.p1-top').classList.add('small');
        [clockEls.h, clockEls.m, clockEls.s].forEach(pop);
        const f = $('#p1flash'); f.classList.remove('go'); void f.offsetWidth; f.classList.add('go');
        ['#p1ring', '#p1ring2'].forEach(s => { const r = $(s); r.classList.remove('go'); void r.offsetWidth; r.classList.add('go'); });
        Snd.boom(); Snd.chime([523, 659, 784, 1047, 1319, 1568], .1); Snd.sparkle();
        const hb = $('#p1hb'); hb.classList.remove('hidden'); void hb.offsetWidth; hb.classList.add('in');
        // crackers!
        const W = innerWidth, H = innerHeight;
        cf.popper(0, H, -Math.PI / 3, 1.1, 90); cf.popper(W, H, -2 * Math.PI / 3, 1.1, 90);
        setTimeout(() => { cf.popper(W * .25, H, -Math.PI / 2, 1, 70); cf.popper(W * .75, H, -Math.PI / 2, 1, 70); }, 450);
        for (let i = 0; i < 6; i++) setTimeout(() => fw.launch(W * (0.12 + i * 0.15), H * (0.12 + Math.random() * .25), i % 3 === 0 ? 'heart' : null), 200 + i * 170);
        setTimeout(() => { fw.show(2.2); cf.shower(true); Snd.applause(4); }, 1400);
        setTimeout(() => { cf.popper(W * .5, H, -Math.PI / 2, 1.3, 110); }, 3200);
        setTimeout(() => { $('#p1next').classList.add('show'); }, 5200);
      };

      const loop = now => {
        if (!st || !st.run) return;
        requestAnimationFrame(loop);
        const dt = Math.min(0.05, (now - last) / 1000); last = now;
        const e = (now - startAt) / 1000;
        if (e >= 0 && st.phase === 'wait') st.phase = 'accel';
        if (st.phase === 'accel') {
          const te = Math.min(e, T);
          virt = (Math.exp(K * te) - 1) / K; rate = Math.exp(K * te);
          if (e >= T) { st.phase = 'final'; st.fin0 = now; }
        } else if (st.phase === 'final') {
          virt = 50 + (now - st.fin0) / 1000; rate = 1;
          if (virt >= 60) { virt = 60; midnight(); }
        }
        if (st.phase === 'accel' || st.phase === 'final') {
          const sec = Math.floor(virt);
          if (sec !== st.lastSec) {
            st.lastSec = sec; clockEls.s.textContent = String(Math.min(sec, 59)).padStart(2, '0'); pop(clockEls.s); tick(sec >= 50);
            if (sec >= 50 && sec < 60) {
              const n = 60 - sec, b = $('#p1big'); b.textContent = n; b.classList.remove('go'); void b.offsetWidth; b.classList.add('go');
              Snd.tone(300 + (10 - n) * 60, .3, 'sine', .3, 0, 40); Snd.tone(110, .25, 'sine', .45);
            }
          }
          $('#p1x').textContent = '×' + rate.toFixed(1);
          $('#p1bar').style.width = Math.min(100, (rate - 1) / (Math.exp(K * T) - 1) * 100) + '%';
        }
        // 3D
        const gl = st.phase === 'boom' ? Math.max(0, 1 - (now - (st.boomT || (st.boomT = now))) / 4000) * .9 + .1 : (st.phase === 'final' ? (virt - 50) / 10 * .5 : 0);
        T3D.uni.uGlow.value += (gl - T3D.uni.uGlow.value) * .08;
        T3D.uni.uTime.value += dt * (1 + rate);
        T3D.earth.rotation.y += dt * spin * (1 + rate * 2.4);
        T3D.stars.rotation.z += dt * 0.004 * (1 + rate * 3);
        T3D.stars.rotation.y += dt * 0.002 * (1 + rate * 3);
        T3D.cam.position.x = Math.sin(now / 5000) * 0.25;
        T3D.cam.lookAt(0, -0.4, 0);
        T3D.renderer.render(T3D.scene, T3D.cam);
      };
      requestAnimationFrame(loop);
      this._rs = () => T3D.size(); addEventListener('resize', this._rs);
      $('#p1next').onclick = () => App.go(2);
    },
    leave() {
      if (!st) return;
      st.run = false; st.fw.stop(); st.cf.stop();
      removeEventListener('resize', this._rs);
      try { st.T3D.renderer.dispose(); } catch (e) {}
      st = null;
    }
  };
  App.reg(1, mod);
})();
