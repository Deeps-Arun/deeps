/* PAGE 4 — secret door → big photo → 💜D💜 → all photos fly into a heart · bgm3 */
(function () {
  const HEART = `<svg viewBox="0 0 32 29"><defs><linearGradient id="hg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#d8a0ff"/><stop offset="1" stop-color="#ff4fb0"/></linearGradient></defs><path d="M16 28C-6 14 3-4 16 6 29-4 38 14 16 28Z" fill="url(#hg)"/></svg>`;
  const html = `
    <canvas class="p4-stars" id="p4st"></canvas>
    <div class="p4-glow" id="p4glow"></div>
    <div class="p4-heartwrap" id="p4heart"></div>
    <div class="p4-doorwrap" id="p4door"><div class="p4-frame"></div><div class="p4-inner"></div>
      <div class="p4-leaf l"></div><div class="p4-leaf r"></div>
      <button class="p4-key" id="p4key" aria-label="Open the secret door">${HEART}</button></div>
    <div class="p4-hint" id="p4hint">✦ tap the glowing heart to open the secret door ✦</div>
    <div class="p4-big" id="p4big"><img alt="Deeps"></div>
    <div class="p4-let" id="p4let">${HEART}<span>D</span>${HEART}</div>
    <div class="p4-title" id="p4title">Every smile of yours, in one heart 💜</div>
    <button class="btn big next-btn" id="p4next">Cut the cake 🎂</button>`;
  let timers = [], run = false, raf = 0;
  const T = (f, ms) => timers.push(setTimeout(f, ms));

  function heartPoints(W, H, n) {
    const pts = [], raw = [];
    for (let i = 0; i <= 720; i++) { const t = i / 720 * Math.PI * 2; raw.push([16 * Math.sin(t) ** 3, 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)]); }
    const cum = [0]; for (let i = 1; i < raw.length; i++) cum.push(cum[i - 1] + Math.hypot(raw[i][0] - raw[i - 1][0], raw[i][1] - raw[i - 1][1]));
    const s = Math.min(W * .8 / 32, H * .62 / 29), cx = W / 2, cy = H * .43 + 2.5 * s;
    for (let k = 0; k < n; k++) { const target = cum[cum.length - 1] * k / n; let j = cum.findIndex(c => c >= target); if (j < 0) j = 0; const p = raw[j]; pts.push([cx + p[0] * s, cy - p[1] * s]); }
    return { pts, size: Math.max(54, Math.min(120, cum[cum.length - 1] * s / n * .98)) };
  }

  const mod = {
    html,
    init(root) {
      const $ = s => root.querySelector(s);
      $('#p4big img').src = App.photo(CFG.doorPhoto);
      $('#p4key').onclick = () => this.open(root);
      $('#p4next').onclick = () => App.go(5);
    },
    enter(root) {
      Snd.bgm('bgm3', .85);
      const $ = s => root.querySelector(s);
      // reset
      timers.forEach(clearTimeout); timers = [];
      $('#p4door').className = 'p4-doorwrap'; $('#p4key').classList.remove('hide'); $('#p4hint').style.opacity = 1;
      $('#p4big').className = 'p4-big'; $('#p4let').className = 'p4-let'; $('#p4title').classList.remove('show'); $('#p4glow').classList.remove('on');
      $('#p4heart').innerHTML = ''; $('#p4heart').classList.remove('beat'); $('#p4next').classList.remove('show');
      // starfield + floating hearts
      const c = $('#p4st'), x = c.getContext('2d'); let st = [];
      const rs = () => { c.width = innerWidth; c.height = innerHeight; st = Array.from({ length: 120 }, () => ({ x: Math.random() * c.width, y: Math.random() * c.height, r: Math.random() * 1.5 + .3, p: Math.random() * 7 })); }; rs(); this._rs = rs; addEventListener('resize', rs);
      run = true; const loop = t => { if (!run) return; raf = requestAnimationFrame(loop); x.clearRect(0, 0, c.width, c.height); st.forEach(s => { x.globalAlpha = .3 + .7 * Math.abs(Math.sin(t / 800 + s.p)); x.fillStyle = '#fff'; x.beginPath(); x.arc(s.x, s.y, s.r, 0, 7); x.fill(); }); }; raf = requestAnimationFrame(loop);
      this.fl = setInterval(() => { const h = document.createElement('div'); h.className = 'p4-float'; h.textContent = ['💜', '💗', '✨', '💖'][Math.random() * 4 | 0]; h.style.left = Math.random() * 100 + '%'; h.style.fontSize = (14 + Math.random() * 22) + 'px'; h.style.animationDuration = (7 + Math.random() * 6) + 's'; root.appendChild(h); setTimeout(() => h.remove(), 14000); }, 900);
    },
    open(root) {
      const $ = s => root.querySelector(s);
      if (this.busy) return; this.busy = true;
      $('#p4key').classList.add('hide'); $('#p4hint').style.opacity = 0;
      const door = $('#p4door'); door.classList.add('rumble'); Snd.boom(); Snd.tone(70, 1.4, 'sawtooth', .25, 0, 40);
      T(() => { door.classList.remove('rumble'); door.classList.add('open'); $('#p4glow').classList.add('on'); Snd.chime([392, 523, 659, 784, 1047, 1319], .12); Snd.sparkle(); }, 1300);
      T(() => { $('#p4big').classList.add('show'); Snd.sparkle(); }, 3000);
      T(() => { door.classList.add('gone'); }, 3600);
      T(() => { $('#p4big').classList.remove('show'); $('#p4big').classList.add('out'); }, 7000);
      T(() => { const l = $('#p4let'); l.classList.add('show'); Snd.chime([523, 784, 1047, 1568], .09); Snd.cracker(); }, 7600);
      T(() => this.heart(root), 10600);
    },
    heart(root) {
      const $ = s => root.querySelector(s);
      const W = innerWidth, H = innerHeight, wrap = $('#p4heart');
      const { pts, size } = heartPoints(W, H, 12);
      $('#p4let').classList.add('small'); $('#p4let').style.top = '52%'; $('#p4let').style.fontSize = 'min(30vw,40vh)';
      pts.forEach((p, i) => {
        const d = document.createElement('div'); d.className = 'p4-ph'; d.style.width = d.style.height = size + 'px'; d.style.left = (W / 2 - size / 2) + 'px'; d.style.top = (H / 2 - size / 2) + 'px';
        d.style.transform = 'scale(0) rotate(0deg)'; d.innerHTML = `<img src="${App.photo(i + 1)}" alt="">`; wrap.appendChild(d);
        const rot = (Math.random() * 12 - 6).toFixed(1);
        T(() => { d.style.opacity = 1; d.style.transform = `translate(${p[0] - W / 2}px,${p[1] - H / 2}px) scale(1) rotate(${rot}deg)`; Snd.pop(); }, 120 + i * 260);
      });
      T(() => { wrap.classList.add('beat'); $('#p4title').classList.add('show'); Snd.chime([523, 659, 784, 1047, 1319], .12); Snd.applause(2); }, 120 + 12 * 260 + 900);
      T(() => { $('#p4next').classList.add('show'); this.busy = false; }, 120 + 12 * 260 + 2600);
    },
    leave() { run = false; cancelAnimationFrame(raf); clearInterval(this.fl); timers.forEach(clearTimeout); timers = []; removeEventListener('resize', this._rs); this.busy = false; }
  };
  App.reg(4, mod);
})();
