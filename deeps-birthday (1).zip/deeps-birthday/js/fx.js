/* Shared effects: fireworks (crackers) + paper confetti */
(function () {
  const rnd = (a, b) => a + Math.random() * (b - a);
  const TAU = Math.PI * 2;

  class Canvas2D {
    constructor(canvas) {
      this.c = canvas; this.x = canvas.getContext('2d');
      this.running = false; this.last = 0;
      this._rs = () => this.resize(); window.addEventListener('resize', this._rs);
      this.resize();
    }
    resize() {
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      this.w = this.c.clientWidth || innerWidth; this.h = this.c.clientHeight || innerHeight;
      this.c.width = this.w * dpr; this.c.height = this.h * dpr;
      this.x.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    start() { if (this.running) return; this.running = true; this.last = performance.now(); requestAnimationFrame(t => this.loop(t)); }
    stop() { this.running = false; }
    loop(t) {
      if (!this.running) return;
      const dt = Math.min(0.05, (t - this.last) / 1000); this.last = t;
      this.step(dt);
      requestAnimationFrame(t2 => this.loop(t2));
    }
  }

  class Fireworks extends Canvas2D {
    constructor(canvas, opt = {}) {
      super(canvas);
      this.p = []; this.rk = []; this.sound = opt.sound !== false; this.auto = 0; this.autoT = 0; this.hueBase = opt.hue;
    }
    palette() {
      const sets = [[340, 20, 45], [270, 300, 330], [190, 210, 160], [45, 30, 55], [0, 330, 20], [120, 90, 60]];
      return sets[Math.random() * sets.length | 0];
    }
    launch(x, ty, type) {
      this.rk.push({ x: x ?? rnd(this.w * .12, this.w * .88), y: this.h + 10, ty: ty ?? rnd(this.h * .12, this.h * .5), vy: -rnd(520, 760), type: type || null, hue: rnd(0, 360) });
      if (this.sound) window.Snd && Snd.whoosh();
    }
    burst(x, y, type, hues) {
      hues = hues || this.palette();
      type = type || ['peony', 'peony', 'ring', 'heart', 'willow', 'star', 'crackle'][Math.random() * 7 | 0];
      const n = type === 'heart' ? 90 : type === 'ring' ? 60 : 110;
      const sp = rnd(180, 320);
      for (let i = 0; i < n; i++) {
        const hue = hues[i % hues.length] + rnd(-8, 8);
        let vx, vy, life = rnd(1, 1.7), g = 160, drag = 0.985, size = rnd(1.4, 2.8);
        const a = (i / n) * TAU;
        if (type === 'heart') { const k = sp / 17; vx = 16 * Math.sin(a) ** 3 * k; vy = -(13 * Math.cos(a) - 5 * Math.cos(2 * a) - 2 * Math.cos(3 * a) - Math.cos(4 * a)) * k; drag = 0.992; }
        else if (type === 'ring') { vx = Math.cos(a) * sp; vy = Math.sin(a) * sp * .45; }
        else if (type === 'willow') { const s = rnd(60, sp); vx = Math.cos(a) * s; vy = Math.sin(a) * s; life = rnd(1.8, 2.8); g = 110; drag = .975; }
        else if (type === 'star') { const arm = (i % 10) / 10; const s = sp * (0.5 + 0.5 * Math.abs(Math.cos(arm * Math.PI * 2.5))); vx = Math.cos(a) * s; vy = Math.sin(a) * s; }
        else { const s = rnd(30, sp); vx = Math.cos(a) * s; vy = Math.sin(a) * s; }
        this.p.push({ x, y, vx, vy, life, max: life, hue, g, drag, size, tw: Math.random() < .3, crackle: type === 'crackle' });
      }
      if (this.sound) { Snd.boom(); }
      // soft flash
      this.flash = 0.25;
    }
    show(rate) { this.auto = rate; }
    step(dt) {
      const x = this.x;
      x.globalCompositeOperation = 'destination-out';
      x.fillStyle = 'rgba(0,0,0,.22)'; x.fillRect(0, 0, this.w, this.h);
      x.globalCompositeOperation = 'lighter';
      if (this.auto > 0) { this.autoT -= dt; if (this.autoT <= 0) { this.autoT = rnd(0.25, 0.75) / this.auto; this.launch(); } }
      for (let i = this.rk.length - 1; i >= 0; i--) {
        const r = this.rk[i]; r.y += r.vy * dt; r.vy *= 0.992;
        x.fillStyle = `hsla(${r.hue},100%,75%,.9)`; x.beginPath(); x.arc(r.x, r.y, 2.2, 0, TAU); x.fill();
        for (let k = 1; k < 6; k++) { x.fillStyle = `hsla(40,100%,70%,${.5 - k * .08})`; x.beginPath(); x.arc(r.x + rnd(-1.5, 1.5), r.y + k * 6, 2 - k * .25, 0, TAU); x.fill(); }
        if (r.y <= r.ty) { this.burst(r.x, r.y, r.type); this.rk.splice(i, 1); }
      }
      for (let i = this.p.length - 1; i >= 0; i--) {
        const p = this.p[i];
        p.life -= dt; if (p.life <= 0) { this.p.splice(i, 1); continue; }
        p.vx *= p.drag; p.vy = p.vy * p.drag + p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt;
        const a = Math.max(0, p.life / p.max);
        const tw = p.tw ? (0.5 + 0.5 * Math.sin(p.life * 40)) : 1;
        x.fillStyle = `hsla(${p.hue},100%,${55 + 25 * a}%,${a * tw})`;
        x.beginPath(); x.arc(p.x, p.y, p.size * (0.5 + a * .7), 0, TAU); x.fill();
        if (p.crackle && a < .35 && Math.random() < .03) { x.fillStyle = '#fff'; x.fillRect(p.x - 2, p.y - 2, 4, 4); if (this.sound && Math.random() < .3) Snd.crackle(1); }
      }
      if (this.p.length > 2200) this.p.splice(0, this.p.length - 2200);
    }
  }

  class Confetti extends Canvas2D {
    constructor(canvas) { super(canvas); this.q = []; this.rain = 0; this.rainT = 0; }
    colors() { return ['#ff5ea8', '#ffd54a', '#7c5cff', '#38d6ff', '#ff8a3d', '#58e08a', '#ffffff', '#ff4d6d']; }
    piece(x, y, vx, vy, kind) {
      const cols = this.colors();
      this.q.push({
        x, y, vx, vy, rot: rnd(0, TAU), vr: rnd(-8, 8), fl: rnd(0, TAU), vf: rnd(4, 11),
        w: kind === 'streamer' ? rnd(4, 7) : rnd(7, 14), h: kind === 'streamer' ? rnd(30, 60) : rnd(5, 9),
        c: cols[Math.random() * cols.length | 0], kind, sw: rnd(0, TAU), life: 0
      });
    }
    popper(x, y, angle, power = 1, n = 70) { // party popper / cracker with paper
      if (window.Snd) Snd.cracker();
      for (let i = 0; i < n; i++) {
        const a = angle + rnd(-0.5, 0.5), s = rnd(350, 1000) * power;
        this.piece(x, y, Math.cos(a) * s, Math.sin(a) * s, Math.random() < .2 ? 'streamer' : (Math.random() < .15 ? 'dot' : 'paper'));
      }
    }
    shower(on) { this.rain = on ? 1 : 0; }
    step(dt) {
      const x = this.x; x.clearRect(0, 0, this.w, this.h);
      if (this.rain) { this.rainT -= dt; if (this.rainT <= 0) { this.rainT = 0.03; this.piece(rnd(0, this.w), -20, rnd(-40, 40), rnd(80, 200), Math.random() < .15 ? 'streamer' : 'paper'); } }
      for (let i = this.q.length - 1; i >= 0; i--) {
        const p = this.q[i]; p.life += dt;
        p.vy += 520 * dt; const d = Math.pow(0.12, dt); p.vx *= d; if (p.vy > 170) p.vy = 170 + (p.vy - 170) * Math.pow(0.02, dt);
        p.sw += dt * 3; p.x += (p.vx + Math.sin(p.sw) * 45) * dt; p.y += p.vy * dt;
        p.rot += p.vr * dt; p.fl += p.vf * dt;
        if (p.y > this.h + 40) { this.q.splice(i, 1); continue; }
        x.save(); x.translate(p.x, p.y); x.rotate(p.rot); x.scale(1, Math.cos(p.fl)); x.fillStyle = p.c;
        if (p.kind === 'dot') { x.beginPath(); x.arc(0, 0, p.h / 1.4, 0, TAU); x.fill(); }
        else if (p.kind === 'streamer') { x.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); }
        else { x.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); }
        x.restore();
      }
      if (this.q.length > 1800) this.q.splice(0, this.q.length - 1800);
    }
  }

  window.FX = { Fireworks, Confetti, rnd };
})();
