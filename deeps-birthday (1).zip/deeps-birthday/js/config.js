/* ─────────────────────────────────────────────────────────────
   ✏️  EDIT ME — everything personal lives in this one file
   ───────────────────────────────────────────────────────────── */
window.CFG = {
  name: 'Deeps',
  fullName: 'DEEPIKA',

  // Page 2 password: 4/11/2003.  Separators are ignored, so 4/11/2003, 04/11/2003,
  // 4-11-2003, 4.11.2003 and 04112003 all work.
  passwordDigits: ['4112003', '04112003'],

  // Page 7 QR code.
  //  - If you host the site online, paste the link in siteUrl and the QR opens the site.
  //  - Otherwise the QR carries the message below (any phone camera shows it).
  siteUrl: '',
  qrMessage: 'Happy Birthday Deeps! You smile every day. Love always.',

  // Page 3 — one blessing under each of the 12 photos (p01 … p12)
  blessings: [
    'May every full moon bring you a wish that comes true. 🌕',
    'Your smile is the sunrise someone needed today. ☀️',
    'May this year pour golden light on every dream you carry. ✨',
    'Stay exactly this graceful, this strong, this you. 🌸',
    'May joy find you first, wherever you are. 🌼',
    'May your laughter echo louder than every worry. 😊',
    'Elegance in every step — may life walk beside you. 🌺',
    'Queen of quiet strength. May all your doors open. 👑',
    'May your days be as warm as this golden light. 🌅',
    'Nature smiles when you smile — keep blooming. 🌿',
    'Blessed with grace, loved by many, protected always. 🙏',
    'Soft as a petal, bright as the stars — happy birthday! 💜'
  ],

  // Page 6 — quiz.  correct = index of the right answer (0-based); null = every answer is right.
  quiz: [
    { q: 'Which moon was shining the night you were born? 🌙', a: ['Waxing gibbous 🌔', 'Full moon 🌕', 'New moon 🌑', 'Blue moon 🔵'], correct: 0 },
    { q: 'What is the date of your birthday?', a: ['14 February', '4 November', '25 December', '1 January'], correct: 1 },
    { q: 'What colour hides inside 💜D💜 ?', a: ['Red', 'Green', 'Purple', 'Yellow'], correct: 2 },
    { q: 'What did the teddy ask you to do today?', a: ['Do homework', 'Make a wish', 'Sleep early', 'Skip the cake'], correct: 1 },
    { q: 'How often should Deeps smile?', a: ['Only on Mondays', 'Once a year', 'Every single day', 'Never'], correct: 2 },
    { q: 'Best part of a birthday?', a: ['The cake 🎂', 'The wishes 🌠', 'The gifts 🎁', 'Being Deeps 💜'], correct: null },
    { q: 'Who is the real star of this whole website?', a: ['The moon', 'The teddies', 'The cake', 'Deeps ⭐'], correct: 3 }
  ],

  // Photo used for the large reveal behind the secret door (1–12) and for the puzzle (1–12)
  doorPhoto: 12,
  puzzlePhoto: 2,
  qrPhoto: 2
};
