/* PAGE 6 — gift box → light → blessing, then 3 games: heart catch, quiz, photo puzzle */
(function () {
  const lotus = `<svg class="mandala" viewBox="0 0 200 200"><g fill="none" stroke="#ffd98a" stroke-width="1.2" opacity=".9">${Array.from({ length: 16 }, (_, i) => `<ellipse cx="100" cy="30" rx="9" ry="26" transform="rotate(${i * 22.5} 100 100)"/>`).join('')}<circle cx="100" cy="100" r="96"/><circle cx="100" cy="100" r="88" stroke-dasharray="2 5"/></g></svg>
    <svg class="mandala r" viewBox="0 0 200 200"><g fill="rgba(255,190,230,.25)" stroke="#ffb8e6" stroke-width="1">${Array.from({ length: 8 }, (_, i) => `<path d="M100 100C84 70 92 42 100 20 108 42 116 70 100 100Z" transform="rotate(${i * 45} 100 100)"/>`).join('')}</g></svg>`;
  const giftSvg = `<svg viewBox="0 0 220 230">
    <ellipse cx="110" cy="218" rx="100" ry="10" fill="rgba(0,0,0,.4)"/>
    <rect x="20" y="96" width="180" height="120" rx="8" fill="#8b5cff"/><rect x="20" y="96" width="180" height="26" fill="rgba(0,0,0,.18)"/>
    <rect x="94" y="96" width="32" height="120" fill="#ffd36e"/>
    <g class="p6-lid"><rect x="10" y="62" width="200" height="42" rx="8" fill="#a07cff"/><rect x="94" y="62" width="32" height="42" fill="#ffe08a"/>
      <path d="M110 62C80 18 40 30 62 56c14 14 40 8 48 6zM110 62c30-44 70-32 48-6-14 14-40 8-48 6z" fill="#ff5ea8" stroke="#c42a76" stroke-width="3"/><circle cx="110" cy="60" r="11" fill="#ff8fc4"/></g></svg>`;
  const html = `
    <canvas class="p6-fx" id="p6cv"></canvas>
    <div class="p6-rays" id="p6rays"></div><div class="p6-glow" id="p6glow"></div>
    <div class="p6-hint" id="p6hint">A gift for you, Deeps 🎁<br><span style="font-size:.4em;font-family:var(--sans);letter-spacing:.2em">TAP TO OPEN</span></div>
    <div class="p6-god" id="p6god">${lotus}<div class="core"><img id="p6img" src="assets/god.png" alt="" onerror="this.remove()"><b>ॐ</b></div></div>
    <div class="p6-gift" id="p6gift">${giftSvg}</div>
    <div class="p6-bless" id="p6bless"><h2>God bless you, Deeps 🙏</h2><p>May every day be as bright as your smile ✨</p><button class="btn big" id="p6play">🎮 Play &amp; win</button></div>
    <div class="p6-hub" id="p6hub"><h2>Birthday Games 🎮</h2>
      <div class="p6-cards">
        <div class="p6-card glass" data-g="1"><span class="tick">✅</span><div class="ic">💜</div><b>Heart Catch</b><small>catch 15 hearts</small></div>
        <div class="p6-card glass" data-g="2"><span class="tick">✅</span><div class="ic">❓</div><b>Deeps Quiz</b><small>choose the answer</small></div>
        <div class="p6-card glass" data-g="3"><span class="tick">✅</span><div class="ic">🧩</div><b>Photo Puzzle</b><small>assemble the photo</small></div>
      </div>
      <div class="p6-msg" id="p6hubmsg">Play any game 💜</div>
      <button class="btn big gold" id="p6fin" style="display:none">Final surprise 💜</button></div>
    <div class="p6-game" id="p6game"><div class="p6-gbar"><span id="p6gt"></span><span id="p6gs"></span><button id="p6back">← back</button></div><div class="p6-gbody" id="p6gb"></div></div>`;

  let run = false, raf = 0, parts = [], done = {}, gstop = null;
  const mod = {
    html,
    init(root) {},
    enter(root) {
      const $ = s => root.querySelector(s);
      Snd.startBox(); done = {};
      root.querySelectorAll('.p6-card').forEach(c => c.classList.remove('done'));
      $('#p6gift').className = 'p6-gift'; ['#p6rays', '#p6glow'].forEach(s => $(s).classList.remove('on')); $('#p6god').classList.remove('on'); $('#p6bless').classList.remove('on'); $('#p6hint').style.opacity = 1; $('#p6hub').classList.remove('on'); $('#p6game').classList.remove('on'); $('#p6fin').style.display = 'none';
      const cv = $('#p6cv'), x = cv.getContext('2d'); let W, H; const rs = () => { W = cv.width = innerWidth; H = cv.height = innerHeight; }; rs(); this._rs = rs; addEventListener('resize', rs);
      parts = []; let mode = 0, t0 = performance.now();
      run = true; const loop = t => { if (!run) return; raf = requestAnimationFrame(loop); x.clearRect(0, 0, W, H); x.globalCompositeOperation = 'lighter';
        if (mode) for (let i = 0; i < 3; i++) parts.push({ x: W / 2 + (Math.random() - .5) * W * .5, y: H * .9 + 10, vy: -40 - Math.random() * 110, vx: (Math.random() - .5) * 30, r: 1 + Math.random() * 3, l: 1, h: 30 + Math.random() * 40 });
        parts = parts.filter(p => (p.l -= .004) > 0 && p.y > -10); parts.forEach(p => { p.x += p.vx / 60 + Math.sin(p.y / 30) * .4; p.y += p.vy / 60; x.fillStyle = `hsla(${p.h},100%,72%,${p.l})`; x.beginPath(); x.arc(p.x, p.y, p.r, 0, 7); x.fill(); });
        if (!mode) { x.fillStyle = 'rgba(255,255,255,.5)'; for (let i = 0; i < 40; i++) { const px = (i * 173) % W, py = (i * 97) % H; x.globalAlpha = .3 + .5 * Math.abs(Math.sin(t / 700 + i)); x.fillRect(px, py, 2, 2); } x.globalAlpha = 1; } x.globalCompositeOperation = 'source-over'; };
      raf = requestAnimationFrame(loop);
      const open = () => {
        if (mode) return; mode = 1; $('#p6gift').classList.add('open'); $('#p6hint').style.opacity = 0; Snd.boom(); Snd.chime([392, 523, 659, 784, 1047, 1319], .13);
        setTimeout(() => { $('#p6rays').classList.add('on'); $('#p6glow').classList.add('on'); Snd.sparkle(); }, 500);
        setTimeout(() => { $('#p6god').classList.add('on'); Snd.chime([523, 659, 784, 1047, 1568], .16); }, 1500);
        setTimeout(() => $('#p6bless').classList.add('on'), 3200);
      };
      $('#p6gift').onclick = open;
      $('#p6play').onclick = () => { $('#p6hub').classList.add('on'); Snd.pop(); };
      $('#p6fin').onclick = () => App.go(7);
      root.querySelectorAll('.p6-card').forEach(c => c.onclick = () => this.game(root, +c.dataset.g));
      $('#p6back').onclick = () => { if (gstop) gstop(); gstop = null; $('#p6game').classList.remove('on'); $('#p6gb').innerHTML = ''; };
    },
    leave() { run = false; cancelAnimationFrame(raf); removeEventListener('resize', this._rs); if (gstop) gstop(); gstop = null; },
    win(root, g, msg) {
      done[g] = true; root.querySelector(`.p6-card[data-g="${g}"]`).classList.add('done'); Snd.win();
      const n = Object.keys(done).length; root.querySelector('#p6hubmsg').textContent = n === 3 ? 'All 3 done — you are amazing! 🏆💜' : n + ' / 3 games completed 💜';
      const f = root.querySelector('#p6fin'); f.style.display = ''; f.textContent = n === 3 ? 'Final surprise 💜' : 'Skip to the final surprise ›';
    },
    game(root, g) {
      const $ = s => root.querySelector(s), gb = $('#p6gb'); gb.innerHTML = ''; $('#p6game').classList.add('on'); $('#p6gs').textContent = '';
      $('#p6gt').textContent = ['', '💜 Heart Catch', '❓ Deeps Quiz', '🧩 Photo Puzzle'][g];
      if (gstop) gstop();
      const finish = (html) => { const m = document.createElement('div'); m.className = 'p6-msg glass'; m.style.cssText = 'position:absolute;inset:auto 0 10%;padding:18px;z-index:5'; m.innerHTML = html + '<br><button class="btn" style="margin-top:12px">Back to games</button>'; gb.appendChild(m); m.querySelector('button').onclick = () => $('#p6back').click(); };
      if (g === 1) {
        const cv = document.createElement('canvas'); gb.appendChild(cv); const x = cv.getContext('2d'); const r = gb.getBoundingClientRect(); cv.width = r.width; cv.height = r.height; const W = cv.width, H = cv.height;
        let bx = W / 2, hs = [], score = 0, time = 30, last = performance.now(), sp = 0, ok = true, over = false; const goal = 15;
        const heart = (cx, cy, s, c) => { x.fillStyle = c; x.beginPath(); x.moveTo(cx, cy + s * .9); x.bezierCurveTo(cx - s * 1.4, cy - s * .2, cx - s * .6, cy - s * 1.1, cx, cy - s * .35); x.bezierCurveTo(cx + s * .6, cy - s * 1.1, cx + s * 1.4, cy - s * .2, cx, cy + s * .9); x.fill(); };
        const mv = e => { const b = cv.getBoundingClientRect(); bx = (e.clientX - b.left) * W / b.width; }; cv.addEventListener('pointermove', mv); cv.addEventListener('pointerdown', mv);
        const key = e => { if (e.key === 'ArrowLeft') bx -= 30; if (e.key === 'ArrowRight') bx += 30; }; addEventListener('keydown', key);
        const loop = now => { if (!ok) return; requestAnimationFrame(loop); const dt = Math.min(.05, (now - last) / 1000); last = now; if (over) return; time -= dt; sp -= dt;
          if (sp <= 0) { sp = .55 - Math.min(.25, (30 - time) / 100); hs.push({ x: 24 + Math.random() * (W - 48), y: -20, v: 120 + Math.random() * 120 + (30 - time) * 3, bad: Math.random() < .18, s: 14 + Math.random() * 6 }); }
          x.clearRect(0, 0, W, H); bx = Math.max(40, Math.min(W - 40, bx));
          hs = hs.filter(h => { h.y += h.v * dt; if (h.y > H - 62 && h.y < H - 30 && Math.abs(h.x - bx) < 46) { if (h.bad) { score = Math.max(0, score - 2); Snd.miss(); } else { score++; Snd.catchHeart(); } return false; } heart(h.x, h.y, h.s, h.bad ? '#8a8aa8' : ['#ff5ea8', '#b88cff', '#ff4d6d', '#ffd36e'][(h.x | 0) % 4]); if (h.bad) { x.fillStyle = '#fff'; x.font = '16px sans-serif'; x.fillText('✖', h.x - 6, h.y + 5); } return h.y < H + 30; });
          x.fillStyle = '#ffd36e'; x.beginPath(); x.moveTo(bx - 46, H - 62); x.lineTo(bx + 46, H - 62); x.lineTo(bx + 34, H - 28); x.lineTo(bx - 34, H - 28); x.closePath(); x.fill(); x.fillStyle = '#c9892a'; x.fillRect(bx - 50, H - 66, 100, 8);
          $('#p6gs').textContent = `💜 ${score}/${goal}  ·  ⏱ ${Math.max(0, time | 0)}s`;
          if (score >= goal) { over = true; mod.win(root, 1); finish('🎉 You caught them all!<br>Every heart is for you 💜'); } else if (time <= 0) { over = true; finish('So close! 💜<br>Try again — hearts love you.'); } };
        requestAnimationFrame(loop); gstop = () => { ok = false; removeEventListener('keydown', key); };
        const hint = document.createElement('div'); hint.className = 'p6-msg'; hint.style.cssText = 'position:absolute;top:10px;left:0;right:0;font-size:14px;opacity:.8;pointer-events:none'; hint.textContent = 'Drag to move the basket · avoid the grey ✖ hearts'; gb.appendChild(hint);
      } else if (g === 2) {
        const Q = CFG.quiz; let i = 0, sc = 0;
        const show = () => { if (i >= Q.length) { mod.win(root, 2); gb.innerHTML = `<div class="p6-q glass"><h3>You scored ${sc} / ${Q.length} 🎉</h3><p>${sc >= Q.length - 1 ? 'You know everything about yourself 😄💜' : 'Still a star ⭐'}</p><button class="btn" id="p6qb">Back to games</button></div>`; gb.querySelector('#p6qb').onclick = () => $('#p6back').click(); return; }
          const q = Q[i]; $('#p6gs').textContent = `${i + 1} / ${Q.length}`; gb.innerHTML = `<div class="p6-q glass"><h3>${q.q}</h3><div class="p6-ans">${q.a.map((a, k) => `<button data-k="${k}">${a}</button>`).join('')}</div></div>`;
          gb.querySelectorAll('button').forEach(b => b.onclick = () => { const k = +b.dataset.k, right = q.correct === null || k === q.correct; gb.querySelectorAll('button').forEach(z => z.disabled = true); b.classList.add(right ? 'good' : 'bad'); if (!right) gb.querySelector(`button[data-k="${q.correct}"]`).classList.add('good'); if (right) { sc++; Snd.catchHeart(); } else Snd.miss(); setTimeout(() => { i++; show(); }, 900); }); };
        show(); gstop = () => {};
      } else {
        const wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;flex-direction:column;align-items:center;width:100%'; gb.appendChild(wrap);
        const grid = document.createElement('div'); grid.className = 'p6-puz'; wrap.appendChild(grid);
        const msg = document.createElement('div'); msg.className = 'p6-msg'; msg.textContent = 'Tap two tiles to swap them 🧩'; wrap.appendChild(msg);
        const peek = document.createElement('button'); peek.className = 'btn ghost'; peek.textContent = '👀 peek'; peek.style.marginTop = '8px'; wrap.appendChild(peek);
        const src = App.photo(CFG.puzzlePhoto); let order = [0, 1, 2, 3, 4, 5, 6, 7, 8], sel = -1;
        do { for (let i = 8; i > 0; i--) { const j = Math.random() * (i + 1) | 0;[order[i], order[j]] = [order[j], order[i]]; } } while (order.every((v, i) => v === i));
        const render = () => { grid.innerHTML = ''; order.forEach((v, pos) => { const t = document.createElement('div'); t.className = 'p6-tile' + (pos === sel ? ' sel' : ''); t.innerHTML = `<img src="${src}" style="left:${-(v % 3) * 100}%;top:${-(v / 3 | 0) * 100}%">`; t.onclick = () => { if (done[3]) return; Snd.tick(); if (sel < 0) { sel = pos; } else { [order[sel], order[pos]] = [order[pos], order[sel]]; sel = -1; } render(); if (order.every((v, i) => v === i)) { grid.style.gap = '0'; mod.win(root, 3); msg.innerHTML = '🎉 Puzzle complete! Beautiful 💜'; const b = document.createElement('button'); b.className = 'btn'; b.textContent = 'Back to games'; b.style.marginTop = '8px'; b.onclick = () => $('#p6back').click(); wrap.appendChild(b); } }; grid.appendChild(t); }); };
        render(); peek.onclick = () => { grid.innerHTML = ''; const t = document.createElement('div'); t.style.cssText = 'grid-area:1/1/4/4;position:relative;overflow:hidden'; t.innerHTML = `<img src="${src}" style="width:100%;height:100%;object-fit:cover">`; grid.appendChild(t); setTimeout(render, 1500); }; gstop = () => {};
      }
    }
  };
  App.reg(6, mod);
})();
