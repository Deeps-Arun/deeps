/* Sound engine: your 3 songs (bgm1-3.mp3) + synthesized crackers, chimes, applause and a gentle music-box tune */
(function () {
  const Snd = {
    ctx: null, master: null, muted: false, els: {}, cur: null, boxTimer: null, boxOn: false, noiseBuf: null, fadeT: {},

    init() {
      if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      const comp = this.ctx.createDynamicsCompressor();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.9;
      this.master.connect(comp); comp.connect(this.ctx.destination);
      // reverb-ish feedback delay bus
      this.fx = this.ctx.createGain(); this.fx.gain.value = 0.5;
      const d = this.ctx.createDelay(1); d.delayTime.value = 0.27;
      const fb = this.ctx.createGain(); fb.gain.value = 0.38;
      const lp = this.ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2600;
      this.fx.connect(d); d.connect(lp); lp.connect(fb); fb.connect(d); lp.connect(this.master);
      const len = this.ctx.sampleRate * 2;
      this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const ch = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) ch[i] = Math.random() * 2 - 1;
    },

    /* ───── music files ───── */
    bgm(name, vol = 0.75, fade = 1200) {
      if (this.cur === name) return;
      this.stopBgm(fade);
      this.stopBox(600);
      if (!name) return;
      let a = this.els[name];
      if (!a) { a = new Audio('assets/audio/' + name + '.mp3'); a.loop = true; a.preload = 'auto'; this.els[name] = a; }
      a._vol = vol;
      a.volume = 0;
      const p = a.play();
      if (p && p.catch) p.catch(() => {});
      this.cur = name;
      this._fade(a, this.muted ? 0 : vol, fade);
    },
    stopBgm(fade = 800) {
      const prev = this.cur ? this.els[this.cur] : null;
      this.cur = null;
      if (prev) { this._fade(prev, 0, fade, () => prev.pause()); }
    },
    _fade(a, to, ms, done) {
      clearInterval(a._fi);
      const from = a.volume, t0 = performance.now();
      a._fi = setInterval(() => {
        const k = Math.min(1, (performance.now() - t0) / ms);
        a.volume = Math.max(0, Math.min(1, from + (to - from) * k));
        if (k >= 1) { clearInterval(a._fi); done && done(); }
      }, 40);
    },
    setMuted(m) {
      this.muted = m;
      if (this.master) this.master.gain.value = m ? 0 : 0.9;
      Object.values(this.els).forEach(a => { a.muted = m; });
      if (this.cur && this.els[this.cur]) this.els[this.cur].muted = m;
    },
    toggleMute() { this.setMuted(!this.muted); return this.muted; },

    /* ───── synth helpers ───── */
    _t() { return this.ctx.currentTime; },
    tone(f, dur = 0.3, type = 'sine', vol = 0.2, when = 0, slideTo = null, bus = null) {
      if (!this.ctx) return;
      const t = this._t() + when, o = this.ctx.createOscillator(), g = this.ctx.createGain();
      o.type = type; o.frequency.setValueAtTime(f, t);
      if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(vol, t + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(this.master); if (bus) g.connect(bus);
      o.start(t); o.stop(t + dur + 0.05);
    },
    noise(dur = 0.3, type = 'lowpass', freq = 1000, vol = 0.3, when = 0, sweepTo = null, q = 1) {
      if (!this.ctx) return;
      const t = this._t() + when, s = this.ctx.createBufferSource(), f = this.ctx.createBiquadFilter(), g = this.ctx.createGain();
      s.buffer = this.noiseBuf; s.loop = true;
      f.type = type; f.Q.value = q; f.frequency.setValueAtTime(freq, t);
      if (sweepTo) f.frequency.exponentialRampToValueAtTime(sweepTo, t + dur);
      g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      s.connect(f); f.connect(g); g.connect(this.master);
      s.start(t, Math.random()); s.stop(t + dur + 0.05);
    },

    /* ───── sound effects ───── */
    tick(big) { this.tone(big ? 880 : 1400, 0.08, 'square', big ? 0.12 : 0.05); },
    whoosh() { this.noise(0.7, 'bandpass', 300, 0.25, 0, 3200, 2); },
    boom() {
      this.noise(0.9, 'lowpass', 900, 0.55, 0, 90);
      this.tone(140, 0.6, 'sine', 0.5, 0, 38);
      this.crackle(10 + (Math.random() * 10 | 0), 0.08);
    },
    crackle(n = 14, delay = 0) {
      for (let i = 0; i < n; i++) this.noise(0.03 + Math.random() * 0.03, 'highpass', 2500 + Math.random() * 4000, 0.18, delay + Math.random() * 0.9);
    },
    cracker() { // party popper
      this.noise(0.12, 'highpass', 1200, 0.7, 0); this.tone(220, 0.1, 'square', 0.25, 0, 60);
      this.noise(0.5, 'bandpass', 4000, 0.18, 0.05, 1500, 1);
    },
    pop() { this.tone(700, 0.12, 'sine', 0.25, 0, 180); },
    sparkle() { for (let i = 0; i < 5; i++) this.tone(1800 + Math.random() * 2800, 0.25, 'sine', 0.05, i * 0.05); },
    chime(notes = [523, 659, 784, 1047], gap = 0.09) { notes.forEach((n, i) => this.tone(n, 0.9, 'sine', 0.13, i * gap, null, this.fx)); },
    unlock() { this.chime([392, 523, 659, 784, 1047, 1319], 0.1); },
    wrong() { this.tone(220, 0.3, 'sawtooth', 0.12, 0, 150); },
    blow() { this.noise(0.9, 'lowpass', 1500, 0.35, 0, 200); },
    cut() { this.noise(0.35, 'bandpass', 1800, 0.25, 0, 5000, 3); },
    applause(sec = 4) {
      const n = Math.floor(sec * 38);
      for (let i = 0; i < n; i++) {
        const when = Math.random() * sec;
        const env = Math.sin(Math.PI * Math.min(1, when / sec));
        this.noise(0.02 + Math.random() * 0.03, 'bandpass', 1500 + Math.random() * 3500, 0.35 * (0.25 + env), when, null, 0.8);
      }
      for (let i = 0; i < 4; i++) this.noise(sec * 0.8, 'bandpass', 1800, 0.05, i * 0.1, 900, 0.5);
    },
    catchHeart() { this.tone(880, 0.12, 'sine', 0.18); this.tone(1320, 0.18, 'sine', 0.14, 0.07); },
    miss() { this.tone(200, 0.25, 'triangle', 0.18, 0, 90); },
    win() { this.chime([523, 659, 784, 1047, 1319, 1568], 0.12); },

    /* ───── gentle music-box (page 5/6) ───── */
    startBox() {
      if (!this.ctx || this.boxOn) return;
      this.stopBgm(900);
      this.boxOn = true;
      const loop = () => {
        if (!this.boxOn) return;
        const len = this._scheduleBox();
        this.boxTimer = setTimeout(loop, (len - 0.4) * 1000);
      };
      this.boxVol = this.ctx.createGain(); this.boxVol.gain.value = 0;
      this.boxVol.connect(this.master); this.boxVol.connect(this.fx);
      this.boxVol.gain.linearRampToValueAtTime(1, this._t() + 1.5);
      loop();
    },
    stopBox(fade = 900) {
      if (!this.boxOn) return;
      this.boxOn = false; clearTimeout(this.boxTimer);
      try { this.boxVol.gain.linearRampToValueAtTime(0, this._t() + fade / 1000); } catch (e) {}
    },
    _bell(f, when, dur, vol) {
      const t = this._t() + when;
      [[1, 1], [2.01, 0.28], [3.98, 0.1]].forEach(([m, a]) => {
        const o = this.ctx.createOscillator(), g = this.ctx.createGain();
        o.type = 'sine'; o.frequency.value = f * m;
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(vol * a, t + 0.01);
        g.gain.exponentialRampToValueAtTime(0.0001, t + dur / m ** 0.3);
        o.connect(g); g.connect(this.boxVol); o.start(t); o.stop(t + dur + 0.1);
      });
    },
    _scheduleBox() {
      const n = { C4: 261.63, D4: 293.66, E4: 329.63, F4: 349.23, G3: 196, A3: 220, G4: 392, A4: 440, B4: 493.88, C5: 523.25, D5: 587.33, E5: 659.25, F5: 698.46, G5: 783.99, E3: 164.81, C3: 130.81, F3: 174.61 };
      const beat = 0.78;
      const mel = [['G4', .75], ['G4', .25], ['A4', 1], ['G4', 1], ['C5', 1], ['B4', 2],
        ['G4', .75], ['G4', .25], ['A4', 1], ['G4', 1], ['D5', 1], ['C5', 2],
        ['G4', .75], ['G4', .25], ['G5', 1], ['E5', 1], ['C5', 1], ['B4', 1], ['A4', 1],
        ['F5', .75], ['F5', .25], ['E5', 1], ['C5', 1], ['D5', 1], ['C5', 3]];
      let t = 0.1;
      mel.forEach(([k, d]) => { this._bell(n[k], t, 1.6, 0.16); t += d * beat; });
      // soft arpeggio bed underneath the melody
      const chords = [['C3', 'E4', 'G4'], ['C3', 'E4', 'G4'], ['G3', 'D4', 'G4'], ['C3', 'E4', 'G4'], ['F3', 'A3', 'C4'], ['C3', 'E4', 'G4'], ['G3', 'D4', 'G4'], ['C3', 'E4', 'G4']];
      let bt = 0.1;
      chords.forEach(c => { for (let r = 0; r < 3; r++) { c.forEach((k, i) => this._bell(n[k] || 261, bt + (i + r * 3) * beat / 3, 1.2, 0.045)); } bt += 3 * beat; });
      // lullaby tail
      const tail = ['E5', 'C5', 'G4', 'C5', 'E5', 'G5', 'E5', 'C5'];
      tail.forEach((k, i) => this._bell(n[k], t + 0.2 + i * beat * 0.5, 1.6, 0.1));
      return t + tail.length * beat * 0.5 + 1;
    }
  };
  window.Snd = Snd;
})();
