/* PAGE 2 — moonlit lake login, password 4/11/2003 · bgm1 */
(function () {
  const html = `
    <canvas id="p2bg"></canvas>
    <div class="p2-moon l" id="p2ml"><img alt="Today's moon" src="${PHOTO_DATA.moon_today}"><div class="p2-cap">Today moon — come and see<small>🌙 tonight's moon</small></div></div>
    <div class="p2-moon r" id="p2mr"><img alt="Your birth moon" src="${PHOTO_DATA.moon_born}"><div class="p2-cap">Your born moon night<small>🌔 4 · 11 · 2003</small></div></div>
    <div class="p2-card glass" id="p2card">
      <div class="p2-lock" id="p2lock">🔒</div>
      <h2 class="script">Welcome, Deeps</h2>
      <p>Whisper the day the moon first saw you ✨<br><span style="opacity:.7">(birth date · D/M/YYYY)</span></p>
      <form class="p2-in" id="p2form" autocomplete="off">
        <input id="p2pw" type="text" inputmode="numeric" placeholder="D/M/YYYY" maxlength="12" aria-label="Password">
        <button class="btn" type="submit">Open 💜</button>
      </form>
      <div class="p2-msg" id="p2msg"></div>
    </div>
    <div class="p2-flood" id="p2flood"></div>
    <div class="p2-tip">🔊 now playing: your song</div>`;

  let run = false, raf = 0;
  const mod = {
    html,
    init(root) {
      const $ = s => root.querySelector(s);
      const form = $('#p2form'), pw = $('#p2pw'), msg = $('#p2msg'), card = $('#p2card');
      pw.addEventListener('input', () => { pw.value = pw.value.replace(/[^0-9\/.\- ]/g, ''); });
      form.addEventListener('submit', e => {
        e.preventDefault();
        const digits = pw.value.replace(/\D/g, '');
        if (CFG.passwordDigits.includes(digits) || CFG.passwordDigits.includes(digits.replace(/^0/, ''))) {
          msg.textContent = 'The moon remembers you 🌙💜';
          card.classList.add('ok'); $('#p2lock').textContent = '🔓';
          Snd.unlock(); Snd.sparkle();
          const f = $('#p2flood'); f.classList.add('go');
          setTimeout(() => App.go(3), 1100);
        } else {
          msg.textContent = 'Hmm… the moon says try again 🌙'; Snd.wrong();
          card.classList.remove('shake'); void card.offsetWidth; card.classList.add('shake');
        }
      });
      this.cv = $('#p2bg'); this.root = root;
    },
    enter(root) {
      Snd.bgm('bgm1', 0.8);
      root.querySelector('#p2flood').classList.remove('go');
      root.querySelector('#p2card').classList.remove('ok');
      root.querySelector('#p2lock').textContent = '🔒';
      setTimeout(() => { try { root.querySelector('#p2pw').focus({ preventScroll: true }); } catch (e) {} }, 800);
      run = true; this.draw(root);
    },
    leave() { run = false; cancelAnimationFrame(raf); },

    draw(root) {
      const cv = this.cv, x = cv.getContext('2d');
      let W, H, hor, stars, dust, diyas, shoot = [], t0 = performance.now();
      const rnd = (a, b) => a + Math.random() * (b - a);
      const resize = () => {
        const dpr = Math.min(2, devicePixelRatio || 1);
        W = innerWidth; H = innerHeight; cv.width = W * dpr; cv.height = H * dpr; x.setTransform(dpr, 0, 0, dpr, 0, 0);
        hor = H * 0.64;
        stars = Array.from({ length: Math.round(W * H / 4200) }, () => ({ x: rnd(0, W), y: rnd(0, hor), r: rnd(.3, 1.5), p: rnd(0, 7), s: rnd(.6, 2) }));
        dust = Array.from({ length: 46 }, () => ({ x: rnd(0, W), y: rnd(hor * .6, H), vx: rnd(-8, 8), vy: rnd(-14, -3), p: rnd(0, 7), r: rnd(1, 2.4) }));
        diyas = Array.from({ length: Math.round(W / 130) }, () => ({ x: rnd(0, W), y: rnd(hor + 30, H - 20), s: rnd(.5, 1.3), v: rnd(4, 11), p: rnd(0, 7) }));
      };
      resize(); addEventListener('resize', resize);
      const hills = (col, base, amp, f, ph) => {
        x.fillStyle = col; x.beginPath(); x.moveTo(0, hor);
        for (let i = 0; i <= W; i += 8) x.lineTo(i, hor - base - amp * (Math.sin(i * f + ph) * .5 + Math.sin(i * f * 2.3 + ph * 2) * .3 + .6));
        x.lineTo(W, hor); x.fill();
      };
      const frame = now => {
        if (!run) return; raf = requestAnimationFrame(frame);
        const t = (now - t0) / 1000;
        // sky
        let g = x.createLinearGradient(0, 0, 0, hor);
        g.addColorStop(0, '#04020d'); g.addColorStop(.5, '#150a38'); g.addColorStop(1, '#3a1c6e');
        x.fillStyle = g; x.fillRect(0, 0, W, hor + 2);
        // aurora ribbons
        x.globalCompositeOperation = 'screen';
        [[170, 255, 200, .16, 0], [270, 130, 255, .14, 2], [320, 220, 255, .1, 4]].forEach(([r, gg, b, a, off], k) => {
          const ag = x.createLinearGradient(0, hor * .05, 0, hor * .65);
          ag.addColorStop(0, `rgba(${r > 200 ? 180 : 60},${gg},${b},0)`); ag.addColorStop(.35, `rgba(${r > 200 ? 160 : 70},${gg},${b},${a * 2})`); ag.addColorStop(1, `rgba(${r > 200 ? 160 : 70},${gg},${b},0)`);
          x.fillStyle = ag; x.beginPath(); x.moveTo(0, hor * .7);
          for (let i = 0; i <= W; i += 10) x.lineTo(i, hor * (.28 + k * .07) + Math.sin(i * .004 + t * .35 + off) * 46 + Math.sin(i * .011 - t * .5 + off) * 18);
          for (let i = W; i >= 0; i -= 10) x.lineTo(i, hor * (.6 + k * .04) + Math.sin(i * .005 + t * .3 + off) * 28);
          x.fill();
        });
        x.globalCompositeOperation = 'source-over';
        // stars
        stars.forEach(s => { x.globalAlpha = .35 + .65 * Math.abs(Math.sin(t * s.s + s.p)); x.fillStyle = '#fff'; x.beginPath(); x.arc(s.x, s.y, s.r, 0, 7); x.fill(); });
        x.globalAlpha = 1;
        // shooting stars
        if (Math.random() < .008) shoot.push({ x: rnd(W * .2, W), y: rnd(0, hor * .4), vx: -rnd(500, 800), vy: rnd(200, 360), l: 1 });
        shoot = shoot.filter(s => { s.x += s.vx / 60; s.y += s.vy / 60; s.l -= .014; const gg = x.createLinearGradient(s.x, s.y, s.x - s.vx / 14, s.y - s.vy / 14); gg.addColorStop(0, `rgba(255,255,255,${s.l})`); gg.addColorStop(1, 'rgba(255,255,255,0)'); x.strokeStyle = gg; x.lineWidth = 2; x.beginPath(); x.moveTo(s.x, s.y); x.lineTo(s.x - s.vx / 14, s.y - s.vy / 14); x.stroke(); return s.l > 0; });
        // hills
        hills('#0c0722', 10, 70, .004, 1); hills('#080517', 0, 46, .006, 4);
        // lake
        g = x.createLinearGradient(0, hor, 0, H); g.addColorStop(0, '#2a1560'); g.addColorStop(.25, '#150a38'); g.addColorStop(1, '#050310');
        x.fillStyle = g; x.fillRect(0, hor, W, H - hor);
        // moon light columns under each moon
        root.querySelectorAll('.p2-moon').forEach((m, i) => {
          const r = m.querySelector('img').getBoundingClientRect(), cx = r.left + r.width / 2;
          const col = i === 1 ? '255,232,180' : '200,185,255';
          for (let k = 0; k < 28; k++) {
            const y = hor + 6 + k * ((H - hor) / 28), w = (r.width * .62) * (1 - k / 40) * (.6 + .4 * Math.sin(t * 1.6 + k * 1.3 + i));
            x.fillStyle = `rgba(${col},${.35 * (1 - k / 28)})`; x.fillRect(cx - w / 2 + Math.sin(t + k) * 6, y, w, 2 + k * .12);
          }
          const rg = x.createRadialGradient(cx, hor, 0, cx, hor, r.width * 1.1); rg.addColorStop(0, `rgba(${col},.28)`); rg.addColorStop(1, `rgba(${col},0)`);
          x.fillStyle = rg; x.fillRect(cx - r.width * 1.1, hor - r.width, r.width * 2.2, r.width * 1.4);
        });
        // ripples
        x.strokeStyle = 'rgba(200,190,255,.08)'; x.lineWidth = 1;
        for (let k = 0; k < 16; k++) { const y = hor + 14 + k * k * 1.4 + (t * 6 % 4); x.beginPath(); for (let i = 0; i <= W; i += 14) x.lineTo(i, y + Math.sin(i * .02 + t + k) * 1.6); x.stroke(); }
        // floating diyas
        diyas.forEach(d => {
          d.x += d.v / 60 * d.s; if (d.x > W + 30) d.x = -30;
          const y = d.y + Math.sin(t * .8 + d.p) * 3, fl = .75 + .25 * Math.sin(t * 9 + d.p * 3);
          const rg = x.createRadialGradient(d.x, y - 4 * d.s, 0, d.x, y - 4 * d.s, 34 * d.s); rg.addColorStop(0, `rgba(255,190,90,${.55 * fl})`); rg.addColorStop(1, 'rgba(255,150,50,0)');
          x.fillStyle = rg; x.fillRect(d.x - 40 * d.s, y - 44 * d.s, 80 * d.s, 80 * d.s);
          x.fillStyle = '#7a3b1c'; x.beginPath(); x.ellipse(d.x, y, 11 * d.s, 4.5 * d.s, 0, 0, 7); x.fill();
          x.fillStyle = '#c4682c'; x.beginPath(); x.ellipse(d.x, y - 1.5 * d.s, 9 * d.s, 3 * d.s, 0, 0, 7); x.fill();
          x.fillStyle = `rgba(255,${200 + 40 * fl | 0},120,1)`; x.beginPath(); x.ellipse(d.x, y - 6 * d.s, 2.4 * d.s, 5.4 * d.s * fl, 0, 0, 7); x.fill();
          x.fillStyle = `rgba(255,170,80,${.18 * fl})`; x.beginPath(); x.ellipse(d.x, y + 8 * d.s, 8 * d.s, 14 * d.s * fl, 0, 0, 7); x.fill();
        });
        // fireflies
        x.globalCompositeOperation = 'lighter';
        dust.forEach(d => {
          d.x += d.vx / 60 + Math.sin(t + d.p) * .3; d.y += d.vy / 60; if (d.y < hor * .55) { d.y = H + 10; d.x = rnd(0, W); }
          const a = .35 + .65 * Math.abs(Math.sin(t * 1.4 + d.p));
          const rg = x.createRadialGradient(d.x, d.y, 0, d.x, d.y, d.r * 6); rg.addColorStop(0, `rgba(255,240,170,${a})`); rg.addColorStop(1, 'rgba(255,220,120,0)');
          x.fillStyle = rg; x.fillRect(d.x - d.r * 6, d.y - d.r * 6, d.r * 12, d.r * 12);
        });
        x.globalCompositeOperation = 'source-over';
      };
      raf = requestAnimationFrame(frame);
    }
  };
  App.reg(2, mod);
})();
