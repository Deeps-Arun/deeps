/* start screen + global mute button + optional ?p=N / #N jump (handy for testing) */
(function () {
  // tiny starfield on the start screen
  const c = document.getElementById('p0stars'), x = c.getContext('2d');
  let stars = [], run = true;
  function rs() { c.width = innerWidth; c.height = innerHeight; stars = Array.from({ length: 140 }, () => ({ x: Math.random() * c.width, y: Math.random() * c.height, r: Math.random() * 1.6 + .2, p: Math.random() * 6 })); }
  rs(); addEventListener('resize', rs);
  (function loop(t) { if (!run) return; x.clearRect(0, 0, c.width, c.height); stars.forEach(s => { x.globalAlpha = .4 + .6 * Math.abs(Math.sin(t / 900 + s.p)); x.fillStyle = '#fff'; x.beginPath(); x.arc(s.x, s.y, s.r, 0, 7); x.fill(); }); requestAnimationFrame(loop); })(0);

  const mute = document.getElementById('muteBtn');
  mute.onclick = () => { const m = Snd.toggleMute(); mute.textContent = m ? '🔇' : '🔊'; };

  function start() {
    Snd.init(); Snd.unlock();
    mute.classList.add('show');
    const q = new URLSearchParams(location.search).get('p') || location.hash.replace('#', '');
    const n = Math.max(1, Math.min(7, parseInt(q, 10) || 1));
    App.go(n);
    setTimeout(() => { run = false; }, 2000);
  }
  document.getElementById('startBtn').addEventListener('click', start);
})();
