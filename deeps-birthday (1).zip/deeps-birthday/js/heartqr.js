/* Heart-shaped QR code. Real, scannable QR (level H): data modules outside the heart are dropped,
   the three finder squares + timing + alignment patterns are always kept. */
(function () {
  let KK = null;
  function inHeart(u, v) { const k = window.__HK || KK || [1.06, 1.0, .07]; const x = u * k[0], y = v * k[1] + k[2]; const a = x * x + y * y - 1; return a * a * a - x * x * y * y * y <= 0; }
  function build(text, ver) {
    const qr = qrcode(ver, 'H'); qr.addData(text, 'Byte'); qr.make(); return qr;
  }
  function draw(canvas, text, o = {}) {
    let qr = null, ver = o.version || 6;
    for (; ver <= 14; ver++) { try { qr = build(text, ver); break; } catch (e) { qr = null; } }
    KK = ver > 7 ? [.92, .88, .03] : null; const n = qr.getModuleCount(), px = canvas.width, q = 1.5, cell = px / (n + q * 2), ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, px, px);
    const keepFn = (r, c) => (r < 8 && c < 8) || (r < 8 && c >= n - 8) || (r >= n - 8 && c < 8) || r === 6 || c === 6;
    // alignment pattern centres
    const al = []; (qrcode.__ap || []);
    const apPos = { 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50], 11: [6, 30, 54], 12: [6, 32, 58], 13: [6, 34, 62], 14: [6, 26, 46, 66] }[ver] || [];
    const inAlign = (r, c) => { for (const a of apPos) for (const b of apPos) { if ((a === 6 && b === 6) || (a === 6 && b === apPos[apPos.length - 1]) || (b === 6 && a === apPos[apPos.length - 1])) continue; if (Math.abs(r - a) <= 2 && Math.abs(c - b) <= 2) return true; } return false; };
    const g = ctx.createLinearGradient(0, 0, px, px); g.addColorStop(0, o.c1 || '#3b1470'); g.addColorStop(.55, o.c2 || '#8a1f78'); g.addColorStop(1, o.c3 || '#c2185b');
    ctx.fillStyle = g;
    const rad = cell * .32;
    ctx.save(); ctx.fillStyle = 'rgba(255,120,190,.16)'; for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) { if (inHeart((c + .5) / n * 2 - 1, -((r + .5) / n * 2 - 1))) ctx.fillRect((c + q) * cell - .5, (r + q) * cell - .5, cell + 1, cell + 1); } ctx.restore();
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) {
      if (!qr.isDark(r, c)) continue;
      const u = (c + .5) / n * 2 - 1, v = -((r + .5) / n * 2 - 1);
      const fn = keepFn(r, c) || inAlign(r, c);
      if (!fn && !inHeart(u, v)) continue;
      const x = (c + q) * cell, y = (r + q) * cell, s = cell * 1.02;
      ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, s, s, fn ? rad * .5 : rad); else ctx.rect(x, y, s, s); ctx.fill();
    }
    return { n, ver, cell, q };
  }
  window.HeartQR = { draw };
})();
