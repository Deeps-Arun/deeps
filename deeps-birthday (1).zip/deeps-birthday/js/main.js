/* Tiny page router. Every page registers itself with App.reg(n, {html, init, enter, leave}) */
(function () {
  const App = {
    cur: 0, pages: {}, busy: false,
    reg(n, mod) { this.pages[n] = mod; },
    el(n) { return document.getElementById('page' + n); },
    photo(i) { const k = 'p' + String(i).padStart(2, '0'); return (window.PHOTO_DATA && PHOTO_DATA[k]) || ('assets/photos/' + k + '.jpg'); },
    go(n, opts = {}) {
      if (this.busy || n === this.cur) return;
      this.busy = true;
      const veil = document.getElementById('veil');
      veil.classList.add('on');
      setTimeout(() => {
        const prev = this.pages[this.cur], pe = this.el(this.cur);
        if (prev && prev.leave) prev.leave();
        if (pe) { pe.classList.remove('on'); }
        let el = this.el(n);
        const mod = this.pages[n];
        if (!el) {
          el = document.createElement('section'); el.className = 'page'; el.id = 'page' + n;
          el.innerHTML = mod.html || ''; document.getElementById('app').appendChild(el);
          if (mod.init) mod.init(el);
        }
        el.classList.add('on');
        this.cur = n;
        if (mod.enter) mod.enter(el);
        document.body.dataset.page = n;
        setTimeout(() => { veil.classList.remove('on'); this.busy = false; }, 120);
      }, opts.instant ? 0 : 560);
    },
    next() { this.go(this.cur + 1); },
    sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
  };
  window.App = App;
})();
