/* PAGE 7 — one-second "Happy Birthday Deeps", lantern sky, heart-shaped QR with Deeps' photo */
(function () {
  const html = `
    <canvas id="p7bg"></canvas>
    <div class="p7-main" id="p7main">
      <div class="p7-text">
        <h1>Happy Birthday<br>Deeps</h1>
        <h2>“You smile every day.”</h2>
        <p>May every day that follows keep that smile glowing. Scan the heart to carry this wish with you 💜</p>
        <div class="p7-btns"><button class="btn gold" id="p7dl">⬇ Save the heart</button><button class="btn ghost" id="p7set">🔗 Set link</button><button class="btn ghost" id="p7re">↺ Replay</button></div>
      </div>
      <div class="p7-qrbox p7-heartbeat" id="p7qrbox"><canvas id="p7qr" width="760" height="760"></canvas><div class="ph"><img id="p7ph" alt="Deeps"></div><div class="scan">scan me 💜</div></div>
    </div>
    <div class="p7-flash" id="p7flash"><h1>Happy Birthday<br>Deeps!</h1></div>`;
  let run = false, raf = 0, tms = [];
  const text = () => CFG.siteUrl || localStorage.getItem('deepsUrl') || (/^https?:/.test(location.protocol) ? location.href.split('#')[0].split('?')[0] : CFG.qrMessage);
  const mod = {
    html,
    init(root) {
      const $ = s => root.querySelector(s);
      $('#p7ph').src = App.photo(CFG.qrPhoto);
      $('#p7re').onclick = () => { Snd.stopBox(); location.href = location.pathname; };
      $('#p7set').onclick = () => { const u = prompt('Paste the website link for the QR code (leave empty for the default message):', localStorage.getItem('deepsUrl') || ''); if (u === null) return; try { u ? localStorage.setItem('deepsUrl', u.trim()) : localStorage.removeItem('deepsUrl'); } catch (e) {} this.qr(root); };
      $('#p7dl').onclick = () => {
        const c = $('#p7qr'), out = document.createElement('canvas'); out.width = out.height = 900; const x = out.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, 900, 900); x.drawImage(c, 70, 70, 760, 760);
        const img = $('#p7ph'), r = 99; x.save(); x.beginPath(); x.arc(450, 60, r, 0, 7); x.clip(); const s = Math.max(2 * r / img.naturalWidth, 2 * r / img.naturalHeight); x.drawImage(img, 450 - img.naturalWidth * s / 2, 456 - img.naturalHeight * s * .4, img.naturalWidth * s, img.naturalHeight * s); x.restore(); x.lineWidth = 8; x.strokeStyle = '#d8a845'; x.beginPath(); x.arc(450, 60, r + 4, 0, 7); x.stroke();
        try { const a = document.createElement('a'); a.download = 'deeps-heart-qr.png'; a.href = out.toDataURL('image/png'); a.click(); } catch (e) { alert('Right-click the heart and choose "Save image".'); }
      };
    },
    qr(root) { HeartQR.draw(root.querySelector('#p7qr'), text()); },
    enter(root) {
      const $ = s => root.querySelector(s);
      Snd.bgm('bgm3', .8);
      this.qr(root);
      root.classList.remove('p7-show'); $('#p7flash').classList.remove('out');
      tms.forEach(clearTimeout);
      tms = [setTimeout(() => { $('#p7flash').classList.add('out'); root.classList.add('p7-show'); Snd.chime([523, 659, 784, 1047, 1319], .1); }, 1000)];
      // lantern sky
      const cv = $('#p7bg'), x = cv.getContext('2d'); let W, H, L = [], S = [], P = [];
      const rs = () => { W = cv.width = innerWidth; H = cv.height = innerHeight; L = Array.from({ length: Math.round(W / 70) }, () => ln(true)); S = Array.from({ length: 90 }, () => ({ x: Math.random() * W, y: Math.random() * H * .6, r: Math.random() * 1.4 + .3, p: Math.random() * 7 })); }; this._rs = rs;
      const ln = (init) => ({ x: Math.random() * W, y: init ? Math.random() * H : H + 40, s: .5 + Math.random() * 1, v: 14 + Math.random() * 26, p: Math.random() * 7, h: 20 + Math.random() * 30 });
      rs(); addEventListener('resize', rs); run = true;
      

      const loop = t => { if (!run) return; raf = requestAnimationFrame(loop); x.clearRect(0, 0, W, H);
        S.forEach(s => { x.globalAlpha = .25 + .6 * Math.abs(Math.sin(t / 900 + s.p)); x.fillStyle = '#fff'; x.beginPath(); x.arc(s.x, s.y, s.r, 0, 7); x.fill(); }); x.globalAlpha = 1;
        // moon
        const mg = x.createRadialGradient(W * .8, H * .16, 0, W * .8, H * .16, 130); mg.addColorStop(0, 'rgba(255,248,220,.95)'); mg.addColorStop(.3, 'rgba(255,236,190,.5)'); mg.addColorStop(1, 'rgba(255,200,230,0)'); x.fillStyle = mg; x.fillRect(W * .8 - 140, H * .16 - 140, 280, 280);
        // hills
        x.fillStyle = '#2a0b45'; x.beginPath(); x.moveTo(0, H); for (let i = 0; i <= W; i += 10) x.lineTo(i, H - 70 - 40 * Math.sin(i * .004 + 1) - 20 * Math.sin(i * .011)); x.lineTo(W, H); x.fill();
        L.forEach((l, i) => { l.y -= l.v / 60; l.x += Math.sin(t / 1500 + l.p) * .3; if (l.y < -60) L[i] = ln(false);
          const w = 26 * l.s, h = 34 * l.s, fl = .8 + .2 * Math.sin(t / 120 + l.p * 5);
          const g = x.createRadialGradient(l.x, l.y, 0, l.x, l.y, 70 * l.s); g.addColorStop(0, `rgba(255,190,90,${.5 * fl})`); g.addColorStop(1, 'rgba(255,120,60,0)'); x.fillStyle = g; x.fillRect(l.x - 80 * l.s, l.y - 80 * l.s, 160 * l.s, 160 * l.s);
          const lg = x.createLinearGradient(l.x, l.y - h / 2, l.x, l.y + h / 2); lg.addColorStop(0, `hsl(${l.h},100%,${68 * fl}%)`); lg.addColorStop(1, `hsl(${l.h - 10},100%,${52 * fl}%)`); x.fillStyle = lg;
          x.beginPath(); x.moveTo(l.x - w / 2, l.y - h / 2); x.lineTo(l.x + w / 2, l.y - h / 2); x.lineTo(l.x + w * .36, l.y + h / 2); x.lineTo(l.x - w * .36, l.y + h / 2); x.closePath(); x.fill(); x.fillStyle = 'rgba(255,255,230,.9)'; x.beginPath(); x.ellipse(l.x, l.y + h / 2, w * .22, 3 * l.s, 0, 0, 7); x.fill(); });
      };
      raf = requestAnimationFrame(loop);
    },
    leave() { run = false; cancelAnimationFrame(raf); tms.forEach(clearTimeout); removeEventListener('resize', this._rs); }
  };
  App.reg(7, mod);
})();
